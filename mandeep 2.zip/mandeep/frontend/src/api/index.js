import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
  // DO NOT set 'Content-Type': 'application/json' here globally,
  // Axios will set it correctly for FormData.
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (response) => response?.data,
  (error) => Promise.reject(new Error(error.response?.data?.message || error.message))
);

export default api;