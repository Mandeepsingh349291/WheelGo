import { AiFillStar, AiOutlineStar } from 'react-icons/ai';

const StarRating = ({ rating, onRate, editable = false, size = 20 }) => {
  const stars = [1,2,3,4,5];
  return (
    <div className="flex space-x-1">
      {stars.map((star) => (
        <span key={star} onClick={() => editable && onRate(star)} className={editable ? 'cursor-pointer' : ''}>
          {star <= rating ? <AiFillStar className="text-accent" size={size} /> : <AiOutlineStar className="text-gray-500" size={size} />}
        </span>
      ))}
    </div>
  );
};

export default StarRating;