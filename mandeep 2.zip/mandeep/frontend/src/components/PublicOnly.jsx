import { Navigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

const PublicOnly = ({ children }) => {
  const { user } = useAuth();
  return !user ? children : <Navigate to="/" />;
};
export default PublicOnly;