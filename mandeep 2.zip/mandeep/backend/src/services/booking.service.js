const Booking = require('../models/Booking');
const Vehicle = require('../models/Vehicle');
const { checkOverlap } = require('../utils/dateOverlap');

const createBookingRequest = async (renterId, vehicleId, startDate, endDate) => {
  const vehicle = await Vehicle.findById(vehicleId);
  if (!vehicle || vehicle.status !== 'active') {
    throw new Error('Vehicle not available');
  }
  if (vehicle.ownerId.toString() === renterId.toString()) {
    throw new Error('You cannot book your own vehicle');
  }

  // Check date overlap
  const conflict = await checkOverlap(vehicleId, startDate, endDate);
  if (conflict) {
    throw new Error('Vehicle is already booked for these dates');
  }

  // Calculate total price (simplified: per day)
  const days = Math.ceil((new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24));
  if (days <= 0) throw new Error('Invalid date range');
  const totalPrice = days * vehicle.pricePerDay;

  const booking = await Booking.create({
    renterId,
    ownerId: vehicle.ownerId,
    vehicleId,
    startDate,
    endDate,
    totalPrice,
    status: 'pending',
    paymentStatus: 'pending',
    ownerDecision: 'pending',
  });

  return booking;
};

const acceptBooking = async (bookingId, ownerId) => {
  const booking = await Booking.findById(bookingId);
  if (!booking) throw new Error('Booking not found');
  if (booking.ownerId.toString() !== ownerId.toString()) throw new Error('Not authorized');
  if (booking.status !== 'pending') throw new Error('Booking is not in pending state');

  booking.status = 'accepted';
  booking.ownerDecision = 'accepted';
  await booking.save();
  return booking;
};

const declineBooking = async (bookingId, ownerId, reason = '') => {
  const booking = await Booking.findById(bookingId);
  if (!booking) throw new Error('Booking not found');
  if (booking.ownerId.toString() !== ownerId.toString()) throw new Error('Not authorized');
  if (booking.status !== 'pending') throw new Error('Booking is not in pending state');

  booking.status = 'declined';
  booking.ownerDecision = 'declined';
  booking.declineReason = reason;
  await booking.save();
  return booking;
};

const cancelBooking = async (bookingId, userId, userRole = 'renter') => {
  const booking = await Booking.findById(bookingId);
  if (!booking) throw new Error('Booking not found');
  if (userRole !== 'admin' && booking.renterId.toString() !== userId.toString()) throw new Error('Not authorized');
  if (!['pending', 'accepted'].includes(booking.status)) throw new Error('Booking cannot be cancelled');

  booking.status = 'cancelled';
  booking.cancellationReason = userRole === 'admin' ? 'Cancelled by admin' : 'Cancelled by renter';
  await booking.save();
  return booking;
};

const markCompleted = async (bookingId, ownerId) => {
  const booking = await Booking.findById(bookingId);
  if (!booking) throw new Error('Booking not found');
  if (booking.ownerId.toString() !== ownerId.toString()) throw new Error('Not authorized');
  if (booking.status !== 'accepted') throw new Error('Only accepted bookings can be marked completed');

  booking.status = 'completed';
  await booking.save();
  return booking;
};

module.exports = { createBookingRequest, acceptBooking, declineBooking, cancelBooking, markCompleted };