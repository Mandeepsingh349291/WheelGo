const Review = require('../models/Review');
const Booking = require('../models/Booking');
const Vehicle = require('../models/Vehicle');

const createReview = async (bookingId, reviewerId, rating, comment) => {
  const booking = await Booking.findById(bookingId);
  if (!booking) throw new Error('Booking not found');
  if (booking.status !== 'completed') throw new Error('Can only review completed bookings');
  if (booking.renterId.toString() !== reviewerId.toString()) throw new Error('Only the renter can review');

  const existingReview = await Review.findOne({ bookingId });
  if (existingReview) throw new Error('Review already exists for this booking');

  const review = await Review.create({
    bookingId,
    vehicleId: booking.vehicleId,
    reviewerId,
    revieweeId: booking.ownerId,
    rating,
    comment,
  });

  // Update vehicle average rating
  const reviews = await Review.find({ vehicleId: booking.vehicleId, isApproved: true });
  const totalRating = reviews.reduce((sum, r) => sum + r.rating, 0);
  const average = reviews.length > 0 ? totalRating / reviews.length : 0;

  await Vehicle.findByIdAndUpdate(booking.vehicleId, {
    averageRating: average,
    totalReviews: reviews.length,
  });

  return review;
};

module.exports = { createReview };

