const router = require('express').Router();
const {
  createVehicle,
  getVehicles,
  getVehicleById,
  updateVehicle,
  deleteVehicle,
} = require('../controllers/vehicle.controller');
const protect = require('../middleware/auth.middleware');
const authorize = require('../middleware/role.middleware');
const { createVehicleRules, updateVehicleRules } = require('../validators/vehicle.validator');
const validate = require('../middleware/validate.middleware');
const upload = require('../middleware/upload.middleware');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Optional auth — populates req.user if token present, but doesn't block if not
const optionalProtect = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer')) {
      const token = authHeader.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id).select('-passwordHash');
    }
  } catch (e) {
    // Invalid or expired token — just continue without setting req.user
  }
  next();
};

router.post('/', protect, authorize('owner', 'admin'), upload.array('images', 10), createVehicleRules, validate, createVehicle);
router.get('/', optionalProtect, getVehicles);
router.get('/:id', getVehicleById);
router.put('/:id', protect, authorize('owner', 'admin'), upload.array('images', 10), updateVehicle);
router.delete('/:id', protect, authorize('owner', 'admin'), deleteVehicle);

module.exports = router;