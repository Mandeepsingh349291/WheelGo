import { format, differenceInDays } from 'date-fns';

export const formatCurrency = (amount) =>
  new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'GBP' }).format(amount);

export const formatDate = (date) => format(new Date(date), 'dd MMM yyyy');
export const calculateDays = (start, end) => differenceInDays(new Date(end), new Date(start));
export const capitalize = (str) => str.charAt(0).toUpperCase() + str.slice(1);