import { Link } from 'react-router-dom';

const PaymentSuccess = () => (
  <div className="text-center py-20">
    <h1 className="text-3xl font-bold text-green-400 mb-4">Payment Successful!</h1>
    <p className="mb-8 text-gray-300">Your booking is now confirmed.</p>
    <Link to="/dashboard/rentals" className="btn-primary">View Rentals</Link>
  </div>
);
export default PaymentSuccess;