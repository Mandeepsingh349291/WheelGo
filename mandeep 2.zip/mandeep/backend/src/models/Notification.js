const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    type: {
      type: String,
      enum: [
        'booking_request',
        'booking_accepted',
        'booking_declined',
        'booking_cancelled',
        'booking_completed',
        'payment',
        'review',
        'system',
      ],
      required: true,
    },
    title: { type: String, required: true },
    message: { type: String, required: true },
    readAt: { type: Date, default: null },
    data: { type: mongoose.Schema.Types.Mixed },
  },
  { timestamps: true }
);
notificationSchema.index({ userId: 1, readAt: 1 });
module.exports = mongoose.model('Notification', notificationSchema);