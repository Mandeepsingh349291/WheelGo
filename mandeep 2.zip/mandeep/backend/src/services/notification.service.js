const Notification = require('../models/Notification');

const createNotification = async (userId, type, title, message, data = {}) => {
  const notification = await Notification.create({
    userId,
    type,
    title,
    message,
    data,
  });
  return notification;
};

module.exports = { createNotification };