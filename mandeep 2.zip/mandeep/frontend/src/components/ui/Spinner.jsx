import { ClipLoader } from 'react-spinners';

const Spinner = ({ size = 40, color = '#F59E0B' }) => (
  <div className="flex justify-center py-10">
    <ClipLoader size={size} color={color} />
  </div>
);
export default Spinner;