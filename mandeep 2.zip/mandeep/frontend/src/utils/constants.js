export const ROLES = { RENTER: 'renter', OWNER: 'owner', ADMIN: 'admin' };
export const BOOKING_STATUS = {
  PENDING: 'pending',
  ACCEPTED: 'accepted',
  DECLINED: 'declined',
  CANCELLED: 'cancelled',
  COMPLETED: 'completed',
};