import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiGrid, FiClock, FiCheckCircle, FiDollarSign, FiArrowRight } from 'react-icons/fi';
import api from '../api';
import Spinner from '../components/ui/Spinner';

const OwnerDashboard = () => {
  const [stats, setStats] = useState({ listings: 0, pending: 0, rentals: 0, earnings: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      try {
        const [listingsRes, bookingsRes] = await Promise.all([
          api.get('/vehicles?owner=me'),
          api.get('/bookings/owner'),
        ]);
        const listings = listingsRes?.data.vehicles || [];
        const bookings = bookingsRes?.data || [];
        const activeListings = listings.filter(v => v.status === 'active').length;
        const pendingRequests = bookings.filter(b => b.status === 'pending').length;
        const completed = bookings.filter(b => b.status === 'completed').length;
        const earnings = bookings
          .filter(b => b.paymentStatus === 'paid')
          .reduce((sum, b) => sum + b.totalPrice, 0);
        setStats({ listings: activeListings, pending: pendingRequests, rentals: completed, earnings });
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, []);

  if (loading) return (
    <div className="flex justify-center items-center h-64">
      <Spinner size={50} color="#F59E0B" />
    </div>
  );

  const statCards = [
    { label: 'Active Listings', value: stats.listings, icon: FiGrid, color: 'from-blue-500/20 to-blue-600/20', borderColor: 'border-blue-500/30' },
    { label: 'Pending Requests', value: stats.pending, icon: FiClock, color: 'from-yellow-500/20 to-orange-500/20', borderColor: 'border-yellow-500/30' },
    { label: 'Completed Rentals', value: stats.rentals, icon: FiCheckCircle, color: 'from-green-500/20 to-emerald-600/20', borderColor: 'border-green-500/30' },
    { label: 'Total Earnings', value: `£${stats.earnings.toFixed(2)}`, icon: FiDollarSign, color: 'from-accent/30 to-orange-500/20', borderColor: 'border-accent/40' },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl md:text-4xl font-bold text-white">Owner Dashboard</h1>
        <p className="text-gray-400 mt-2">Manage your fleet and track your performance</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card, idx) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            whileHover={{ y: -5, scale: 1.02 }}
            className={`relative overflow-hidden rounded-2xl bg-gradient-to-br ${card.color} backdrop-blur-sm border ${card.borderColor} shadow-xl transition-all duration-300`}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-3">
                <card.icon className="text-3xl text-accent" />
                <span className="text-xs font-medium text-gray-300 bg-black/30 px-2 py-1 rounded-full">This month</span>
              </div>
              <p className="text-gray-200 text-sm uppercase tracking-wide">{card.label}</p>
              <p className="text-3xl md:text-4xl font-black text-white mt-2">
                {typeof card.value === 'number' ? card.value.toLocaleString() : card.value}
              </p>
            </div>
            {/* Decorative shine */}
            <div className="absolute -top-10 -right-10 w-24 h-24 bg-white/5 rounded-full blur-2xl" />
          </motion.div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-6">
        <h2 className="text-xl font-semibold text-white mb-4">Quick Actions</h2>
        <div className="flex flex-wrap gap-4">
          <Link
            to="/dashboard/listings"
            className="inline-flex items-center gap-2 px-6 py-3 bg-accent/20 hover:bg-accent/30 text-accent rounded-xl transition-all duration-200 font-medium"
          >
            <FiGrid /> My Listings <FiArrowRight className="group-hover:translate-x-1 transition" />
          </Link>
          <Link
            to="/dashboard/requests"
            className="inline-flex items-center gap-2 px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all duration-200 font-medium"
          >
            <FiClock /> Booking Requests <FiArrowRight />
          </Link>
        </div>
      </div>

      {/* Optional: Recent activity or tips */}
      <div className="bg-accent/5 border border-accent/20 rounded-2xl p-5">
        <p className="text-gray-300 text-sm flex items-center gap-2">
          <span className="text-accent text-lg">💡</span> 
          Tip: Respond to booking requests quickly to increase your earnings. Vehicles with high response rates get featured.
        </p>
      </div>
    </div>
  );
};
export default OwnerDashboard;