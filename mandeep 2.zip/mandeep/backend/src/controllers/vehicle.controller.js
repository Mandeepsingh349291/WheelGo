const Vehicle = require('../models/Vehicle');
const { successResponse, errorResponse } = require('../utils/response');
const fs = require('fs');
const path = require('path');

const createVehicle = async (req, res, next) => {
  try {
    const ownerId = req.user.id;
    const {
      title, description, vehicleType, pricePerDay, location,
      seats, transmission, fuelType
    } = req.body;
    const images = req.files ? req.files.map((file) => file.path) : [];

    const vehicle = await Vehicle.create({
      ownerId,
      title,
      description,
      vehicleType,
      pricePerDay,
      location,
      images,
      seats: seats || 4,
      transmission: transmission || 'manual',
      fuelType: fuelType || 'petrol',
    });

    successResponse(res, vehicle, 'Vehicle created', 201);
  } catch (err) {
    next(err);
  }
};

const getVehicles = async (req, res, next) => {
  try {
    const {
      page = 1, limit = 10, type, location, minPrice, maxPrice,
      seats, transmission, fuelType, sort, owner, query: searchQuery,
      startDate, endDate
    } = req.query;

    const isOwnerFetch = owner === 'me' && req.user;

    // If owner=me but no authenticated user found, return empty
    if (owner === 'me' && !req.user) {
      return successResponse(res, { vehicles: [], total: 0, page: 1, pages: 0 });
    }

    // Owner fetching their own listings: skip status/approval filter, show all their listings
    // Public search: only show active and approved listings
    const query = isOwnerFetch
      ? { ownerId: req.user.id }
      : { status: 'active', isApproved: true };

    // Search query on title/description
    if (searchQuery) {
      query.$or = [
        { title: { $regex: searchQuery, $options: 'i' } },
        { description: { $regex: searchQuery, $options: 'i' } },
      ];
    }

    if (type) query.vehicleType = type;
    if (location) query.location = { $regex: location, $options: 'i' };
    if (seats) query.seats = Number(seats);
    if (transmission) query.transmission = transmission;
    if (fuelType) query.fuelType = fuelType;

    if (minPrice || maxPrice) {
      query.pricePerDay = {};
      if (minPrice) query.pricePerDay.$gte = Number(minPrice);
      if (maxPrice) query.pricePerDay.$lte = Number(maxPrice);
    }

    let vehicleIds = null;

    // NEW: Handle date-based availability filter
    if (startDate && endDate) {
      const Booking = require('../models/Booking');
      const bookedVehicles = await Booking.find({
        status: { $in: ['pending', 'accepted'] },
        startDate: { $lt: new Date(endDate) },
        endDate: { $gt: new Date(startDate) },
      }).select('vehicleId');

      const bookedVehicleIds = bookedVehicles.map(b => b.vehicleId.toString());
      vehicleIds = bookedVehicleIds.length > 0 ? bookedVehicleIds : null;
    }

    let sortOption = {};
    if (sort === 'price_asc') sortOption.pricePerDay = 1;
    else if (sort === 'price_desc') sortOption.pricePerDay = -1;
    else if (sort === 'rating') sortOption.averageRating = -1;
    else sortOption.createdAt = -1;

    const total = await Vehicle.countDocuments(query);
    
    let vehicleQuery = Vehicle.find(query)
      .sort(sortOption)
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .populate('ownerId', 'name avatarUrl');

    // NEW: Exclude booked vehicles if date filter was applied
    if (vehicleIds && vehicleIds.length > 0) {
      vehicleQuery = vehicleQuery.where('_id').nin(vehicleIds);
    }

    const vehicles = await vehicleQuery;

    successResponse(res, {
      vehicles,
      total: vehicles.length, // Use actual count after filtering
      page: Number(page),
      pages: Math.ceil(vehicles.length / limit),
    });
  } catch (err) {
    next(err);
  }
};

const getVehicleById = async (req, res, next) => {
  try {
    const vehicle = await Vehicle.findById(req.params.id)
      .populate('ownerId', 'name avatarUrl phone email');
    if (!vehicle) return errorResponse(res, 'Vehicle not found', 404);
    successResponse(res, vehicle);
  } catch (err) {
    next(err);
  }
};

// Update a vehicle (owner/admin only)
const updateVehicle = async (req, res, next) => {
  try {
    const vehicle = await Vehicle.findById(req.params.id);
    if (!vehicle) return errorResponse(res, 'Vehicle not found', 404);

    // Check ownership or admin role
    if (vehicle.ownerId.toString() !== req.user.id && req.user.role !== 'admin') {
      return errorResponse(res, 'Not authorized', 403);
    }

    // Update text fields
    const allowedFields = [
      'title', 'description', 'vehicleType', 'pricePerDay',
      'location', 'seats', 'transmission', 'fuelType', 'status'
    ];
    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) {
        vehicle[field] = req.body[field];
      }
    });

    // Handle images: combine existing (kept by user) + new uploads
    let finalImages = [];

    // 1. If frontend sent existingImages (JSON string of URLs to keep), parse it
    if (req.body.existingImages) {
      try {
        finalImages = JSON.parse(req.body.existingImages);
      } catch (err) {
        finalImages = vehicle.images || [];
      }
    } else {
      finalImages = vehicle.images || [];
    }

    // 2. Add newly uploaded images (Cloudinary URLs)
    if (req.files && req.files.length > 0) {
      const newImageUrls = req.files.map((file) => file.path);
      finalImages.push(...newImageUrls);
    }

    vehicle.images = finalImages;

    await vehicle.save();
    successResponse(res, vehicle, 'Vehicle updated');
  } catch (err) {
    next(err);
  }
};

// Delete a vehicle (owner/admin only)
const deleteVehicle = async (req, res, next) => {
  try {
    const vehicle = await Vehicle.findById(req.params.id);
    if (!vehicle) return errorResponse(res, 'Vehicle not found', 404);

    if (vehicle.ownerId.toString() !== req.user.id && req.user.role !== 'admin') {
      return errorResponse(res, 'Not authorized', 403);
    }

    await Vehicle.deleteOne({ _id: vehicle._id });
    successResponse(res, null, 'Vehicle deleted');
  } catch (err) {
    next(err);
  }
};
module.exports = {
  createVehicle,
  getVehicles,
  getVehicleById,
  updateVehicle,
  deleteVehicle,
};