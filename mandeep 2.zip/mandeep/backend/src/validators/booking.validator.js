const { body } = require('express-validator');

const createBookingRules = [
  body('vehicleId').isMongoId().withMessage('Valid vehicle ID required'),
  body('startDate').isISO8601().toDate().withMessage('Start date must be a valid date'),
  body('endDate').isISO8601().toDate().withMessage('End date must be a valid date'),
  body('startDate').custom((value, { req }) => {
    if (new Date(value) >= new Date(req.body.endDate)) {
      throw new Error('End date must be after start date');
    }
    return true;
  }),
];

const acceptRejectRules = [
  body('reason').optional().isString().trim().isLength({ max: 500 }),
];

module.exports = { createBookingRules, acceptRejectRules };
