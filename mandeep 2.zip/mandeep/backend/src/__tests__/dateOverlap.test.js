const Booking = require('../models/Booking');
const { checkOverlap } = require('../utils/dateOverlap');

jest.mock('../models/Booking', () => ({
  findOne: jest.fn()
}));

describe('checkOverlap — Date Overlap Prevention', () => {

  beforeEach(() => {
    Booking.findOne.mockReset();
  });

  test('UT-01: rejects overlapping dates — 12-18 May vs existing 10-15 May', async () => {
    Booking.findOne.mockResolvedValue({ _id: 'existing-booking' });
    const result = await checkOverlap('vehicleId123', '2025-05-12', '2025-05-18');
    expect(result).toBe(true);
  });

  test('UT-02: allows booking ending before existing starts — 5-9 May vs 10-15 May', async () => {
    Booking.findOne.mockResolvedValue(null);
    const result = await checkOverlap('vehicleId123', '2025-05-05', '2025-05-09');
    expect(result).toBe(false);
  });

  test('UT-03: rejects partial overlap — 8-12 May vs existing 10-15 May', async () => {
    Booking.findOne.mockResolvedValue({ _id: 'existing-booking' });
    const result = await checkOverlap('vehicleId123', '2025-05-08', '2025-05-12');
    expect(result).toBe(true);
  });

  test('UT-04: allows booking starting after existing ends — 16-20 May vs 10-15 May', async () => {
    Booking.findOne.mockResolvedValue(null);
    const result = await checkOverlap('vehicleId123', '2025-05-16', '2025-05-20');
    expect(result).toBe(false);
  });

  test('UT-05: rejects exact same date range — 10-15 May vs 10-15 May', async () => {
    Booking.findOne.mockResolvedValue({ _id: 'existing-booking' });
    const result = await checkOverlap('vehicleId123', '2025-05-10', '2025-05-15');
    expect(result).toBe(true);
  });
  test('UT-06: allows adjacent booking sharing boundary date — 15-18 May vs 10-15 May', async () => {
    Booking.findOne.mockResolvedValue(null);
    const result = await checkOverlap('vehicleId123', '2025-05-15', '2025-05-18');
    expect(result).toBe(false);
  });
});