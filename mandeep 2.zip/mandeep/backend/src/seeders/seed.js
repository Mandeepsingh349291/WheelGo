require('dotenv').config({ path: './.env' }); // adjust if needed
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');
const Vehicle = require('../models/Vehicle');

const seed = async () => {
  try {
    await connectDB();
    console.log('Clearing existing data...');
    await User.deleteMany({});
    await Vehicle.deleteMany({});

    // Create users
    const owner = await User.create({
      name: 'John Owner',
      email: 'owner@wheelgo.com',
      passwordHash: 'password123',
      role: 'owner',
      phone: '+1234567890',
    });

    const renter = await User.create({
      name: 'Jane Renter',
      email: 'renter@wheelgo.com',
      passwordHash: 'password123',
      role: 'renter',
    });

    const admin = await User.create({
      name: 'Admin',
      email: 'admin@wheelgo.com',
      passwordHash: 'admin123',
      role: 'admin',
    });
    // Create vehicles
    await Vehicle.create([
      {
        ownerId: owner._id,
        title: 'Tesla Model 3',
        description: 'Smooth electric ride',
        vehicleType: 'car',
        pricePerDay: 120,
        location: 'New York',
        seats: 5,
        transmission: 'automatic',
        fuelType: 'electric',
        images: ['/uploads/sample-car.jpg'],
      },
      {
        ownerId: owner._id,
        title: 'Honda CB500X',
        description: 'Adventure bike',
        vehicleType: 'bike',
        pricePerDay: 45,
        location: 'Los Angeles',
        seats: 2,
        transmission: 'manual',
        fuelType: 'petrol',
        images: ['/uploads/sample-bike.jpg'],
      },
    ]);
    console.log('Seeding completed!');
    process.exit(0);
  } catch (error) {
    console.error('Seeding failed:', error);
    process.exit(1);
  }
};
seed();