const router = require('express').Router();
const { updateProfile, changePassword, uploadAvatar } = require('../controllers/user.controller');
const protect = require('../middleware/auth.middleware');
const { updateProfileRules, changePasswordRules } = require('../validators/user.validator');
const validate = require('../middleware/validate.middleware');
const upload = require('../middleware/upload.middleware');

router.put('/me', protect, updateProfileRules, validate, updateProfile);
router.put('/me/password', protect, changePasswordRules, validate, changePassword);
router.post('/me/avatar', protect, upload.single('avatar'), uploadAvatar);

module.exports = router;