import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { Menu, Transition } from '@headlessui/react';
import { Bars3Icon, XMarkIcon } from '@heroicons/react/24/outline';
import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiUser, FiBell, FiCheck, FiCheckCircle } from 'react-icons/fi';
import { useNotifications } from '../hooks/useNotifications';
import { formatDate } from '../utils/helpers';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const notifRef = useRef(null);
  const { notifications, unreadCount, markAsRead, markAllRead } = useNotifications();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const userInitial = user?.name ? user.name.charAt(0).toUpperCase() : 'U';

  // Close notification panel when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (notifRef.current && !notifRef.current.contains(e.target)) {
        setNotifOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getNotifIcon = (type) => {
    switch (type) {
      case 'booking_request': return '📋';
      case 'booking_accepted': return '✅';
      case 'booking_declined': return '❌';
      case 'booking_cancelled': return '🚫';
      case 'payment': return '💳';
      case 'review': return '⭐';
      default: return '🔔';
    }
  };

  return (
    <nav className="bg-surface-light shadow-lg sticky top-0 z-50 border-b border-surface-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">

          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-accent to-orange-500 rounded-lg flex items-center justify-center shadow-md">
              <span className="text-white font-bold text-lg">W</span>
            </div>
            <span className="font-bold text-xl text-accent">WheelGo</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-4">
            <Link to="/search" className="text-gray-300 hover:text-accent transition-colors">Search</Link>

            {user ? (
              <>
                <Link to="/dashboard" className="text-gray-300 hover:text-accent">Dashboard</Link>

                {/* Notification Bell */}
                <div className="relative" ref={notifRef}>
                  <button
                    onClick={() => setNotifOpen(!notifOpen)}
                    className="relative p-1 rounded-full hover:bg-white/10 transition"
                  >
                    <FiBell className="text-gray-300 hover:text-accent" size={20} />
                    {unreadCount > 0 && (
                      <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center font-bold">
                        {unreadCount > 9 ? '9+' : unreadCount}
                      </span>
                    )}
                  </button>

                  {/* Notification Dropdown Panel */}
                  <AnimatePresence>
                    {notifOpen && (
                      <motion.div
                        initial={{ opacity: 0, y: -10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: -10, scale: 0.95 }}
                        transition={{ duration: 0.15 }}
                        className="absolute right-0 mt-2 w-80 bg-gray-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden z-50"
                      >
                        {/* Header */}
                        <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-white/5">
                          <h3 className="text-white font-semibold text-sm">Notifications</h3>
                          {unreadCount > 0 && (
                            <button
                              onClick={() => { markAllRead(); }}
                              className="text-xs text-accent hover:text-accent-hover flex items-center gap-1 transition"
                            >
                              <FiCheckCircle size={12} /> Mark all read
                            </button>
                          )}
                        </div>

                        {/* Notification List */}
                        <div className="max-h-80 overflow-y-auto">
                          {notifications.length === 0 ? (
                            <div className="py-10 text-center">
                              <FiBell className="text-gray-600 mx-auto mb-2" size={28} />
                              <p className="text-gray-500 text-sm">No notifications yet</p>
                            </div>
                          ) : (
                            notifications.map((notif) => (
                              <div
                                key={notif._id}
                                onClick={() => !notif.readAt && markAsRead(notif._id)}
                                className={`flex items-start gap-3 px-4 py-3 border-b border-white/5 cursor-pointer hover:bg-white/5 transition ${
                                  !notif.readAt ? 'bg-accent/5' : ''
                                }`}
                              >
                                {/* Icon */}
                                <span className="text-xl mt-0.5 flex-shrink-0">
                                  {getNotifIcon(notif.type)}
                                </span>

                                {/* Content */}
                                <div className="flex-1 min-w-0">
                                  <p className={`text-sm font-medium ${!notif.readAt ? 'text-white' : 'text-gray-400'}`}>
                                    {notif.title}
                                  </p>
                                  <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">
                                    {notif.message}
                                  </p>
                                  <p className="text-xs text-gray-600 mt-1">
                                    {formatDate(notif.createdAt)}
                                  </p>
                                </div>

                                {/* Unread dot */}
                                {!notif.readAt && (
                                  <div className="w-2 h-2 bg-accent rounded-full flex-shrink-0 mt-1.5" />
                                )}
                              </div>
                            ))
                          )}
                        </div>

                        {/* Footer */}
                        {notifications.length > 0 && (
                          <div className="px-4 py-2 border-t border-white/10 bg-white/5 text-center">
                            <p className="text-xs text-gray-500">
                              {unreadCount > 0 ? `${unreadCount} unread` : 'All caught up!'}
                            </p>
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* User Menu */}
                <Menu as="div" className="relative">
                  <Menu.Button className="flex items-center space-x-1">
                    <div className="w-8 h-8 rounded-full bg-accent/20 text-accent flex items-center justify-center font-semibold text-sm">
                      {userInitial}
                    </div>
                    <span className="text-sm font-medium text-gray-300">{user.name}</span>
                  </Menu.Button>
                  <Transition
                    enter="transition ease-out duration-100"
                    enterFrom="transform opacity-0 scale-95"
                    enterTo="transform opacity-100 scale-100"
                    leave="transition ease-in duration-75"
                    leaveFrom="transform opacity-100 scale-100"
                    leaveTo="transform opacity-0 scale-95"
                  >
                    <Menu.Items className="absolute right-0 mt-2 w-48 bg-surface-light border border-surface-border rounded-md shadow-lg py-1 z-20">
                      <Menu.Item>
                        {({ active }) => (
                          <Link to="/profile" className={`block px-4 py-2 text-sm ${active ? 'bg-surface-border' : ''} text-gray-300`}>
                            Profile
                          </Link>
                        )}
                      </Menu.Item>
                      <Menu.Item>
                        {({ active }) => (
                          <button onClick={handleLogout} className={`block w-full text-left px-4 py-2 text-sm ${active ? 'bg-surface-border' : ''} text-gray-300`}>
                            Logout
                          </button>
                        )}
                      </Menu.Item>
                    </Menu.Items>
                  </Transition>
                </Menu>
              </>
            ) : (
              <>
                <Link to="/login" className="btn-primary">Sign In</Link>
                <Link to="/register" className="btn-secondary">Register</Link>
              </>
            )}
          </div>

          {/* Mobile Hamburger */}
          <div className="md:hidden">
            <button onClick={() => setMobileOpen(!mobileOpen)} className="text-gray-300">
              {mobileOpen ? <XMarkIcon className="h-6 w-6" /> : <Bars3Icon className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="md:hidden bg-surface-light border-t border-surface-border"
        >
          <Link to="/search" className="block px-4 py-2 text-gray-300 hover:bg-surface-border">Search</Link>
          {user ? (
            <>
              <Link to="/dashboard" className="block px-4 py-2 text-gray-300 hover:bg-surface-border">Dashboard</Link>
              <Link to="/profile" className="block px-4 py-2 text-gray-300 hover:bg-surface-border">Profile</Link>
              {unreadCount > 0 && (
                <div className="px-4 py-2 text-sm text-accent">
                  🔔 {unreadCount} unread notification{unreadCount > 1 ? 's' : ''}
                </div>
              )}
              <button onClick={handleLogout} className="block w-full text-left px-4 py-2 text-gray-300 hover:bg-surface-border">
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="block px-4 py-2 text-gray-300 hover:bg-surface-border">Sign In</Link>
              <Link to="/register" className="block px-4 py-2 text-gray-300 hover:bg-surface-border">Register</Link>
            </>
          )}
        </motion.div>
      )}
    </nav>
  );
};
export default Navbar;