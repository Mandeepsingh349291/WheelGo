const paymentService = require('../services/payment.service');
const { successResponse } = require('../utils/response');

const createOrder = async (req, res, next) => {
  try {
    const { bookingId } = req.body;
    const order = await paymentService.createPayPalOrder(bookingId, req.user.id);
    successResponse(res, { orderId: order.id, approvalUrl: order.links.find(l => l.rel === 'approve')?.href });
  } catch (err) {
    next(err);
  }
};

const captureOrder = async (req, res, next) => {
  try {
    const { orderId, bookingId } = req.body;
    const result = await paymentService.capturePayPalOrder(orderId, bookingId, req.user.id);
    successResponse(res, result, 'Payment captured successfully');
  } catch (err) {
    next(err);
  }
};

const getPaymentByBooking = async (req, res, next) => {
  try {
    const Payment = require('../models/Payment');
    const payment = await Payment.findOne({ bookingId: req.params.bookingId });
    if (!payment) return res.status(404).json({ success: false, message: 'Payment not found' });
    successResponse(res, payment);
  } catch (err) {
    next(err);
  }
};
module.exports = { createOrder, captureOrder, getPaymentByBooking };