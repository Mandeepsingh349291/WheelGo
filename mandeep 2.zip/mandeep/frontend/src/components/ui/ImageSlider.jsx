import { useState } from 'react';
import { ChevronLeftIcon, ChevronRightIcon } from '@heroicons/react/24/outline';
import { motion, AnimatePresence } from 'framer-motion';

const ImageSlider = ({ images }) => {
  const [current, setCurrent] = useState(0);
  const slides = images?.length ? images : ['/assets/images/placeholder.jpg'];

  const prev = () => setCurrent((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
  const next = () => setCurrent((prev) => (prev === slides.length - 1 ? 0 : prev + 1));

  return (
    <div className="relative w-full h-64 md:h-96 rounded-xl overflow-hidden bg-surface-light">
      <AnimatePresence mode="wait">
        <motion.img
          key={current}
          src={slides[current]}
          alt="Vehicle"
          className="w-full h-full object-cover"
          initial={{ opacity: 0, x: 100 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -100 }}
          transition={{ duration: 0.3 }}
        />
      </AnimatePresence>
      {slides.length > 1 && (
        <>
          <button onClick={prev} className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 rounded-full p-1 hover:bg-black/70"><ChevronLeftIcon className="h-5 w-5" /></button>
          <button onClick={next} className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 rounded-full p-1 hover:bg-black/70"><ChevronRightIcon className="h-5 w-5" /></button>
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex space-x-1">
            {slides.map((_, idx) => (
              <button key={idx} onClick={() => setCurrent(idx)} className={`h-2 w-2 rounded-full ${idx === current ? 'bg-accent' : 'bg-gray-400'}`} />
            ))}
          </div>
        </>
      )}
    </div>
  );
};
export default ImageSlider;