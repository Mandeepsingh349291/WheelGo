const Notification = require('../models/Notification');
const { successResponse } = require('../utils/response');

// Get notifications for logged-in user
const getNotifications = async (req, res, next) => {
  try {
    const { unreadOnly } = req.query;
    const filter = { userId: req.user.id };
    if (unreadOnly === 'true') filter.readAt = null;
    const notifications = await Notification.find(filter)
      .sort('-createdAt')
      .limit(50);
    const unreadCount = await Notification.countDocuments({ userId: req.user.id, readAt: null });
    successResponse(res, { notifications, unreadCount });
  } catch (err) {
    next(err);
  }
};

// Mark a notification as read
const markAsRead = async (req, res, next) => {
  try {
    const { id } = req.params;
    const notification = await Notification.findOneAndUpdate(
      { _id: id, userId: req.user.id },
      { readAt: new Date() },
      { new: true }
    );
    if (!notification) return res.status(404).json({ success: false, message: 'Notification not found' });
    successResponse(res, notification, 'Notification marked as read');
  } catch (err) {
    next(err);
  }
};

// Mark all as read
const markAllAsRead = async (req, res, next) => {
  try {
    await Notification.updateMany(
      { userId: req.user.id, readAt: null },
      { readAt: new Date() }
    );
    successResponse(res, null, 'All notifications marked as read');
  } catch (err) {
    next(err);
  }
};
module.exports = { getNotifications, markAsRead, markAllAsRead };