import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { 
  FiUser, FiCalendar, FiDollarSign, FiCheckCircle, 
  FiXCircle, FiClock, FiInfo, FiAlertCircle 
} from 'react-icons/fi';
import api from '../api';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import Spinner from '../components/ui/Spinner';
import EmptyState from '../components/ui/EmptyState';
import { formatDate, calculateDays, formatCurrency } from '../utils/helpers';
import toast from 'react-hot-toast';

const OwnerBookingRequests = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchBookings = async () => {
    try {
      const res = await api.get('/bookings/owner');
      setBookings(res?.data || []);
    } catch (err) { 
      toast.error(err.message); 
    } finally { 
      setLoading(false); 
    }
  };

  useEffect(() => { fetchBookings(); }, []);

  const handleDecision = async (id, action) => {
    const reason = action === 'decline' ? prompt('Reason (optional):') : '';
    try {
      if (action === 'accept') {
        await api.patch(`/bookings/${id}/accept`, { reason });
        toast.success('Booking accepted');
      } else {
        await api.patch(`/bookings/${id}/decline`, { reason });
        toast.success('Booking declined');
      }
      fetchBookings();
    } catch (err) { 
      toast.error(err.message); 
    }
  };

  if (loading) return (
    <div className="flex justify-center items-center h-64">
      <Spinner size={50} color="#F59E0B" />
    </div>
  );
  
  if (bookings.length === 0) return (
    <EmptyState message="No booking requests yet." />
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl md:text-4xl font-bold text-white">Booking Requests</h1>
        <p className="text-gray-400 mt-1">Manage incoming rental requests from renters</p>
      </div>

      {/* Requests List */}
      <div className="space-y-4">
        {bookings.map((booking, idx) => (
          <motion.div
            key={booking._id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            whileHover={{ y: -2 }}
            className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-5 hover:border-accent/30 transition-all"
          >
            <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
              {/* Left content */}
              <div className="flex-1 space-y-3">
                <h3 className="font-bold text-xl text-white">
                  {booking.vehicleId?.title || 'Vehicle'}
                </h3>
                
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-gray-300">
                  <span className="flex items-center gap-1">
                    <FiUser className="text-accent" size={14} />
                    {booking.renterId?.name} requested
                  </span>
                  <span className="flex items-center gap-1">
                    <FiCalendar className="text-accent" size={14} />
                    {formatDate(booking.startDate)} – {formatDate(booking.endDate)}
                    <span className="text-gray-500">({calculateDays(booking.startDate, booking.endDate)} days)</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <FiDollarSign className="text-accent" size={14} />
                    {formatCurrency(booking.totalPrice)}
                  </span>
                </div>

                {/* Explicit status labels with badges */}
                <div className="flex flex-wrap gap-4 mt-2 pt-2 border-t border-white/10">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-300 font-medium">Booking status:</span>
                    <Badge status={booking.status} />
                    <div className="relative group/tip">
                      <FiInfo className="text-gray-500 cursor-help" size={12} />
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-800 text-xs text-white rounded whitespace-nowrap opacity-0 group-hover/tip:opacity-100 transition pointer-events-none z-20">
                        {booking.status === 'pending' && 'Waiting for your decision – accept or decline'}
                        {booking.status === 'accepted' && 'You accepted this booking. Awaiting payment from renter.'}
                        {booking.status === 'declined' && 'You declined this request.'}
                        {booking.status === 'cancelled' && 'Cancelled by renter or system.'}
                        {booking.status === 'completed' && 'Trip finished.'}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-300 font-medium">Payment status:</span>
                    <Badge status={booking.paymentStatus} />
                    <div className="relative group/tip">
                      <FiInfo className="text-gray-500 cursor-help" size={12} />
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-800 text-xs text-white rounded whitespace-nowrap opacity-0 group-hover/tip:opacity-100 transition pointer-events-none z-20">
                        {booking.paymentStatus === 'pending' && 'Payment not yet made by renter.'}
                        {booking.paymentStatus === 'paid' && 'Payment completed. Funds are available.'}
                        {booking.paymentStatus === 'refunded' && 'Payment refunded.'}
                        {booking.paymentStatus === 'failed' && 'Payment attempt failed.'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action buttons for pending requests with helper text */}
              {booking.status === 'pending' && (
                <div className="flex flex-col items-end gap-2">
                  <div className="flex flex-row lg:flex-col gap-2 lg:min-w-[160px]">
                    <Button 
                      onClick={() => handleDecision(booking._id, 'accept')} 
                      className="bg-gradient-to-r from-green-500 to-emerald-600 hover:shadow-lg flex items-center justify-center gap-1"
                    >
                      <FiCheckCircle /> Accept
                    </Button>
                    <Button 
                      onClick={() => handleDecision(booking._id, 'decline')} 
                      variant="outline" 
                      className="border-red-500 text-red-400 hover:bg-red-500/10 flex items-center justify-center gap-1"
                    >
                      <FiXCircle /> Decline
                    </Button>
                  </div>
                  <p className="text-xs text-gray-400 text-right">Accepting will request payment from renter</p>
                </div>
              )}

              {/* Message for already processed bookings */}
              {booking.status !== 'pending' && (
                <div className="text-sm text-gray-400 flex items-center gap-1">
                  <FiClock /> Already {booking.status}
                </div>
              )}
            </div>

            {/* Decline reason if any */}
            {booking.status === 'declined' && booking.declineReason && (
              <div className="mt-3 pt-2 border-t border-white/10 text-xs text-gray-400 flex items-center gap-1">
                <FiAlertCircle className="text-accent" />
                Decline reason: {booking.declineReason}
              </div>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default OwnerBookingRequests;