const Pagination = ({ page, pages, onChange }) => {
  if (pages <= 1) return null;
  const getPages = () => {
    const arr = [];
    for (let i = 1; i <= pages; i++) {
      if (i === 1 || i === pages || (i >= page - 1 && i <= page + 1)) {
        arr.push(i);
      } else if (arr[arr.length-1] !== '...') {
        arr.push('...');
      }
    }
    return arr;
  };
  return (
    <div className="flex justify-center space-x-1 mt-8">
      <button disabled={page === 1} onClick={() => onChange(page - 1)} className="px-3 py-1 text-sm rounded-md bg-surface-light border border-surface-border hover:bg-primary disabled:opacity-50">Prev</button>
      {getPages().map((p, idx) =>
        p === '...' ? <span key={idx} className="px-3 py-1">…</span> :
        <button key={p} onClick={() => onChange(p)} className={`px-3 py-1 text-sm rounded-md ${p === page ? 'bg-accent text-white' : 'bg-surface-light border border-surface-border hover:bg-primary'}`}>{p}</button>
      )}
      <button disabled={page === pages} onClick={() => onChange(page + 1)} className="px-3 py-1 text-sm rounded-md bg-surface-light border border-surface-border hover:bg-primary disabled:opacity-50">Next</button>
    </div>
  );
};

export default Pagination;