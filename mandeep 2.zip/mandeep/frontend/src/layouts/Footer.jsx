const Footer = () => (
  <footer className="bg-surface-light border-t border-surface-border py-6 text-center text-gray-400">
    <p>&copy; {new Date().getFullYear()} WheelGo. All rights reserved.</p>
  </footer>
); 
export default Footer;