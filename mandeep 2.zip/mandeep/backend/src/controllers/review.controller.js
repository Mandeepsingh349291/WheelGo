const reviewService = require('../services/review.service');
const Review = require('../models/Review');
const { successResponse } = require('../utils/response');

const createReview = async (req, res, next) => {
  try {
    const { bookingId, rating, comment } = req.body;
    const review = await reviewService.createReview(bookingId, req.user.id, rating, comment);
    successResponse(res, review, 'Review submitted', 201);
  } catch (err) {
    next(err);
  }
};

const getVehicleReviews = async (req, res, next) => {
  try {
    const { vehicleId } = req.params;
    const reviews = await Review.find({ vehicleId, isApproved: true })
      .populate('reviewerId', 'name avatarUrl')
      .sort('-createdAt');
    successResponse(res, reviews);
  } catch (err) {
    next(err);
  }
};

const deleteReview = async (req, res, next) => {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) return res.status(404).json({ success: false, message: 'Review not found' });
    if (review.reviewerId.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }
    await Review.deleteOne({ _id: review._id });
    successResponse(res, null, 'Review deleted');
  } catch (err) {
    next(err);
  }
};

module.exports = { createReview, getVehicleReviews, deleteReview };
