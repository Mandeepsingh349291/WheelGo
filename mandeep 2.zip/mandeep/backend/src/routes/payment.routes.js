const router = require('express').Router();
const protect = require('../middleware/auth.middleware');
const { createOrder, captureOrder, getPaymentByBooking } = require('../controllers/payment.controller');
const { createOrderRules, captureOrderRules } = require('../validators/payment.validator');
const validate = require('../middleware/validate.middleware');

router.post('/create-order', protect, createOrderRules, validate, createOrder);
router.post('/capture-order', protect, captureOrderRules, validate, captureOrder);
router.get('/booking/:bookingId', protect, getPaymentByBooking);
module.exports = router;