const router = require('express').Router();
const protect = require('../middleware/auth.middleware');
const { createReview, getVehicleReviews, deleteReview } = require('../controllers/review.controller');
const { createReviewRules } = require('../validators/review.validator');
const validate = require('../middleware/validate.middleware');

router.post('/', protect, createReviewRules, validate, createReview);
router.get('/vehicle/:vehicleId', getVehicleReviews);
router.delete('/:id', protect, deleteReview);
module.exports = router;