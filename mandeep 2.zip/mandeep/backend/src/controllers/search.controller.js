const Vehicle = require('../models/Vehicle');
const { successResponse } = require('../utils/response');

const searchVehicles = async (req, res, next) => {
  try {
    const {
      query,
      type,
      location,
      startDate,
      endDate,
      minPrice,
      maxPrice,
      seats,
      transmission,
      fuelType,
      sort,
      page = 1,
      limit = 10,
    } = req.query;

    const filter = { status: 'active', isApproved: true };

    // Text search on title/description
    if (query) {
      filter.$or = [
        { title: { $regex: query, $options: 'i' } },
        { description: { $regex: query, $options: 'i' } },
      ];
    }

    if (type) filter.vehicleType = type;
    if (location) filter.location = { $regex: location, $options: 'i' };
    if (seats) filter.seats = { $gte: Number(seats) };
    if (transmission) filter.transmission = transmission;
    if (fuelType) filter.fuelType = fuelType;

    if (minPrice || maxPrice) {
      filter.pricePerDay = {};
      if (minPrice) filter.pricePerDay.$gte = Number(minPrice);
      if (maxPrice) filter.pricePerDay.$lte = Number(maxPrice);
    }

    // Date availability: exclude vehicles with overlapping confirmed bookings
    if (startDate && endDate) {
      const Booking = require('../models/Booking');
      const overlappingBookings = await Booking.find({
        status: { $in: ['accepted', 'pending'] },
        $or: [
          { startDate: { $lt: new Date(endDate) }, endDate: { $gt: new Date(startDate) } }
        ]
      }).distinct('vehicleId');
      filter._id = { $nin: overlappingBookings };
    }

    let sortOption = {};
    if (sort === 'price_asc') sortOption.pricePerDay = 1;
    else if (sort === 'price_desc') sortOption.pricePerDay = -1;
    else if (sort === 'rating') sortOption.averageRating = -1;
    else sortOption.createdAt = -1;

    const total = await Vehicle.countDocuments(filter);
    const vehicles = await Vehicle.find(filter)
      .sort(sortOption)
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .populate('ownerId', 'name avatarUrl');

    successResponse(res, {
      vehicles,
      total,
      page: Number(page),
      pages: Math.ceil(total / limit),
    });
  } catch (err) {
    next(err);
  }
};

module.exports = { searchVehicles };