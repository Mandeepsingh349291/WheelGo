import DatePickerComponent from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const DatePicker = ({ label, startDate, endDate, onChange, className = '', placeholderText = 'Select dates', ...props }) => (
  <div className="w-full">
    {label && <label className="block text-sm font-medium mb-1 text-gray-300">{label}</label>}
    <DatePickerComponent
      selectsRange
      startDate={startDate}
      endDate={endDate}
      onChange={onChange}
      placeholderText={placeholderText}
      className={`bg-black/40 border border-white/20 rounded-xl py-2 px-3 text-white w-full focus:outline-none focus:border-accent ${className}`}
      minDate={new Date()}
      dateFormat="dd/MM/yyyy"
      {...props}
    />
  </div>
);
export default DatePicker;