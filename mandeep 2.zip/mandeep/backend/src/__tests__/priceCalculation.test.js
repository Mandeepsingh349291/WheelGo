describe('Price Calculation Logic', () => {

  const calculatePrice = (startDate, endDate, pricePerDay) => {
    const days = Math.ceil(
      (new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24)
    );
    return days * pricePerDay;
  };

  test('UT-07: calculates correct price for 5-day rental at £45/day', () => {
    const total = calculatePrice('2025-08-10', '2025-08-15', 45);
    expect(total).toBe(225);
  });

  test('UT-08: calculates correct price for 1-day rental', () => {
    const total = calculatePrice('2025-08-10', '2025-08-11', 45);
    expect(total).toBe(45);
  });

  test('UT-09: calculates correct price for 10-day rental', () => {
    const total = calculatePrice('2025-08-01', '2025-08-11', 60);
    expect(total).toBe(600);
  });

});