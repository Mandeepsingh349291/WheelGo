const statusColors = {
  pending: 'bg-yellow-500/20 text-yellow-400',
  accepted: 'bg-green-500/20 text-green-400',
  declined: 'bg-red-500/20 text-red-400',
  cancelled: 'bg-gray-500/20 text-gray-400',
  completed: 'bg-blue-500/20 text-blue-400',
  paid: 'bg-emerald-500/20 text-emerald-400',
  refunded: 'bg-purple-500/20 text-purple-400',
  failed: 'bg-red-500/20 text-red-400',
};
const Badge = ({ status }) => (
  <span className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-medium capitalize ${statusColors[status] || 'bg-gray-500/20 text-gray-300'}`}>
    {status}
  </span>
);
export default Badge;