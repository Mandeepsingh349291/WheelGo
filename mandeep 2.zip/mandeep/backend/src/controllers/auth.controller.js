const User = require('../models/User');
const { generateToken } = require('../utils/token');
const { successResponse, errorResponse } = require('../utils/response');

const register = async (req, res, next) => {
  try {
    const { name, email, password, role, phone } = req.body;
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return errorResponse(res, 'Email already in use', 400);
    }

    const user = await User.create({ name, email, passwordHash: password, role, phone });
    const token = generateToken({ id: user._id });

    successResponse(res, {
      user: { id: user._id, name: user.name, email: user.email, role: user.role },
      token,
    }, 'Registration successful', 201);
  } catch (err) {
    next(err);
  }
};

const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await user.comparePassword(password))) {
      return errorResponse(res, 'Invalid email or password', 401);
    }
    if (!user.isActive) {
      return errorResponse(res, 'Account deactivated', 403);
    }
    const token = generateToken({ id: user._id });
    successResponse(res, {
      user: { id: user._id, name: user.name, email: user.email, role: user.role },
      token,
    }, 'Login successful');
  } catch (err) {
    next(err);
  }
};

const getMe = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id).select('-passwordHash');
    successResponse(res, user);
  } catch (err) {
    next(err);
  }
};

module.exports = { register, login, getMe };

