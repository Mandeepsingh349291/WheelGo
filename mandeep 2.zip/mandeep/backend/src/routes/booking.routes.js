const router = require('express').Router();
const protect = require('../middleware/auth.middleware');
const {
  createBooking,
  getRenterBookings,
  getOwnerBookings,
  acceptBooking,
  declineBooking,
  cancelBooking,
  markCompleted,
} = require('../controllers/booking.controller');
const { createBookingRules, acceptRejectRules } = require('../validators/booking.validator');
const validate = require('../middleware/validate.middleware');

router.post('/', protect, createBookingRules, validate, createBooking);
router.get('/me', protect, getRenterBookings);
router.get('/owner', protect, getOwnerBookings);
router.patch('/:id/accept', protect, acceptRejectRules, validate, acceptBooking);
router.patch('/:id/decline', protect, acceptRejectRules, validate, declineBooking);
router.patch('/:id/cancel', protect, cancelBooking);
router.patch('/:id/complete', protect, markCompleted);
module.exports = router;