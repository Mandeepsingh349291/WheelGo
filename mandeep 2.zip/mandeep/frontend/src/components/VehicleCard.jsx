import { Link } from 'react-router-dom';
import { formatCurrency } from '../utils/helpers';
import { AiFillStar, AiOutlineHeart } from 'react-icons/ai';
import { motion } from 'framer-motion';
import { useState } from 'react';

const VehicleCard = ({ vehicle }) => {
  const [liked, setLiked] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -8 }}
      transition={{ duration: 0.3 }}
      className="group relative bg-gradient-to-b from-surface-light to-surface rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl hover:shadow-accent/20 transition-all duration-300"
    >
      {/* Image container with overlay */}
      <div className="relative overflow-hidden h-56">
        <img
          src={vehicle.images?.[0] || 'https://placehold.co/600x400/1F2937/9CA3AF?text=No+Image'}
          alt={vehicle.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        {/* Gradient overlay on hover */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        {/* Like button */}
        <button
          onClick={() => setLiked(!liked)}
          className="absolute top-3 right-3 bg-black/50 backdrop-blur-sm rounded-full p-2 hover:bg-black/70 transition-colors z-10"
        >
          <AiOutlineHeart
            size={20}
            className={liked ? 'text-red-500 fill-red-500' : 'text-white'}
          />
        </button>

        {/* Price badge (floating) */}
        <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-md rounded-full px-3 py-1 text-sm font-bold text-white">
          {formatCurrency(vehicle.pricePerDay)}<span className="text-xs text-gray-300">/day</span>
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        <div className="flex justify-between items-start gap-2 mb-2">
          <h3 className="font-bold text-xl text-white line-clamp-1 group-hover:text-accent transition-colors">
            {vehicle.title}
          </h3>
        </div>

        <p className="text-sm text-gray-400 mb-3 flex items-center gap-1">
          <span>📍</span> {vehicle.location}
        </p>

        <div className="flex items-center justify-between mt-2 pt-3 border-t border-white/10">
          <div className="flex items-center gap-2">
            <div className="flex items-center text-sm bg-accent/10 px-2 py-1 rounded-full">
              <AiFillStar className="text-accent mr-1" size={14} />
              <span className="text-white font-medium">
                {vehicle.averageRating?.toFixed(1) || 'New'}
              </span>
            </div>
            <span className="text-xs text-gray-500 capitalize">• {vehicle.vehicleType}</span>
          </div>
          
          <Link
            to={`/vehicles/${vehicle._id}`}
            className="text-accent text-sm font-medium hover:underline flex items-center gap-1 group/link"
          >
            View details
            <span className="transition-transform group-hover/link:translate-x-1">→</span>
          </Link>
        </div>
      </div>

      {/* Hover border glow effect */}
      <div className="absolute inset-0 rounded-2xl ring-2 ring-accent/0 group-hover:ring-accent/30 transition-all duration-300 pointer-events-none" />
    </motion.div>
  );
};

export default VehicleCard;