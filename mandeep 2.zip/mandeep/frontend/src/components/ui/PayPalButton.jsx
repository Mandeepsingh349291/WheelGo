import { PayPalButtons } from '@paypal/react-paypal-js';
import api from '../../api';
import toast from 'react-hot-toast';

const PayPalButton = ({ bookingId, amount, onSuccess }) => {
  const createOrder = async () => {
    try {
      const res = await api.post('/payments/create-order', { bookingId });
      return res.data.orderId;
    } catch (err) {
      toast.error(err.message);
      throw err;
    }
  };

  const onApprove = async (data, actions) => {
    try {
      await api.post('/payments/capture-order', { orderId: data.orderID, bookingId });
      toast.success('Payment successful!');
      if (onSuccess) onSuccess();
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <PayPalButtons
      createOrder={createOrder}
      onApprove={onApprove}
      style={{ layout: 'horizontal' }}
    />
  );
};
export default PayPalButton;