const Booking = require('../models/Booking');

/**
 * Check if a vehicle has any overlapping accepted/pending bookings for the given date range.
 * @param {string} vehicleId
 * @param {Date} startDate
 * @param {Date} endDate
 * @param {string} [excludeBookingId] - optional, ignore this booking (for updates)
 * @returns {Promise<boolean>} true if conflict exists
 */
const checkOverlap = async (vehicleId, startDate, endDate, excludeBookingId = null) => {
  const query = {
    vehicleId,
    status: { $in: ['pending', 'accepted'] },
    $or: [
      { startDate: { $lt: endDate }, endDate: { $gt: startDate } }
    ],
  };
  if (excludeBookingId) {
    query._id = { $ne: excludeBookingId };
  }
  const conflict = await Booking.findOne(query);
  return !!conflict;
};

module.exports = { checkOverlap };