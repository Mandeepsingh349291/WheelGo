import { Link } from 'react-router-dom';

const PaymentCancel = () => (
  <div className="text-center py-20">
    <h1 className="text-3xl font-bold text-red-400 mb-4">Payment Cancelled</h1>
    <p className="mb-8 text-gray-300">Your payment was not completed.</p>
    <Link to="/search" className="btn-primary">Back to Search</Link>
  </div>
);
export default PaymentCancel;