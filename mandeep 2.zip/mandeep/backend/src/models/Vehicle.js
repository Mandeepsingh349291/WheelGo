const mongoose = require('mongoose');

const vehicleSchema = new mongoose.Schema(
  {
    ownerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    title: { type: String, required: true, trim: true },
    description: { type: String, default: '' },
    vehicleType: { type: String, enum: ['car', 'bike'], required: true },
    pricePerDay: { type: Number, required: true, min: 0 },
    location: { type: String, required: true },
    images: [{ type: String }], // URLs
    seats: { type: Number, default: 4 },
    transmission: { type: String, enum: ['automatic', 'manual'], default: 'manual' },
    fuelType: { type: String, enum: ['petrol', 'diesel', 'electric', 'hybrid'], default: 'petrol' },
    availabilityCalendar: {
      type: Map,
      of: [Date],
      default: {},
    },
    status: {
      type: String,
      enum: ['active', 'inactive', 'moderation'],
      default: 'active',
    },
    averageRating: { type: Number, default: 0 },
    totalReviews: { type: Number, default: 0 },
    isApproved: { type: Boolean, default: true }, // admin moderation
  },
  { timestamps: true }
);

// Index for search
vehicleSchema.index({ vehicleType: 1, location: 1, pricePerDay: 1, seats: 1 });
module.exports = mongoose.model('Vehicle', vehicleSchema);