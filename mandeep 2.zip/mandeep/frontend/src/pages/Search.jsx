import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { FiSearch, FiX, FiMapPin, FiFilter, FiChevronDown, FiSliders } from 'react-icons/fi';
import api from '../api';
import VehicleCard from '../components/VehicleCard';
import Button from '../components/ui/Button';
import DatePicker from '../components/ui/DatePicker';
import Pagination from '../components/ui/Pagination';
import Spinner from '../components/ui/Spinner';
import EmptyState from '../components/ui/EmptyState';

const Search = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [pagination, setPagination] = useState({ page: 1, pages: 1, total: 0 });
  const [filters, setFilters] = useState({
    query: '',
    type: '',
    location: '',
    minPrice: '',
    maxPrice: '',
    startDate: null,
    endDate: null,
  });
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [priceRange, setPriceRange] = useState([0, 500]);

  // Sync price range with filters
  useEffect(() => {
    if (filters.minPrice) setPriceRange([+filters.minPrice, priceRange[1]]);
    if (filters.maxPrice) setPriceRange([priceRange[0], +filters.maxPrice]);
  }, [filters.minPrice, filters.maxPrice]);

  useEffect(() => {
    const params = Object.fromEntries(searchParams.entries());
    const start = params.startDate ? new Date(params.startDate) : null;
    const end = params.endDate ? new Date(params.endDate) : null;
    setFilters(prev => ({ ...prev, ...params, startDate: start, endDate: end }));
    if (params.minPrice) setPriceRange([+params.minPrice, priceRange[1]]);
    if (params.maxPrice) setPriceRange([priceRange[0], +params.maxPrice]);
    fetchVehicles(params);
  }, [searchParams]);

  const fetchVehicles = async (params) => {
    setLoading(true);
    try {
      const res = await api.get('/vehicles', { params });
      setVehicles(res.data.vehicles);
      setPagination({ page: res.data.page, pages: res.data.pages, total: res.data.total });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleFilter = (e) => {
    e.preventDefault();
    const params = {};
    Object.entries(filters).forEach(([key, val]) => {
      if (val) {
        if (key === 'startDate' || key === 'endDate') params[key] = val.toISOString();
        else params[key] = val;
      }
    });
    setSearchParams(params);
  };

  const handleChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const handlePriceChange = (values) => {
    setPriceRange(values);
    setFilters({ ...filters, minPrice: values[0], maxPrice: values[1] });
  };

  const clearFilters = () => {
    setFilters({
      query: '', type: '', location: '', minPrice: '', maxPrice: '',
      startDate: null, endDate: null,
    });
    setPriceRange([0, 500]);
    setSearchParams({});
  };

  const hasActiveFilters = Object.values(filters).some(v => v && v !== '');

  const removeFilter = (key) => {
    const newFilters = { ...filters, [key]: '' };
    setFilters(newFilters);
    const params = {};
    Object.entries(newFilters).forEach(([k, v]) => v && (params[k] = v));
    setSearchParams(params);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-slate-900 to-black">
      {/* Hero */}
      <div className="relative pt-20 pb-12 text-center border-b border-white/10 bg-black/30 backdrop-blur-sm">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent"
        >
          Find Your Perfect Ride
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-gray-300 mt-4 text-lg max-w-2xl mx-auto"
        >
          Search from hundreds of cars and bikes. Filter by price, location, and availability.
        </motion.p>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-10">
        {/* Filter Bar */}
        <div className="bg-white/5 backdrop-blur-xl rounded-2xl border border-white/20 p-6 mb-8 shadow-2xl">
          <form onSubmit={handleFilter}>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  name="query"
                  value={filters.query}
                  onChange={handleChange}
                  placeholder="Search by keyword"
                  className="w-full bg-black/40 border border-white/20 rounded-xl py-3 pl-10 pr-4 text-white placeholder-gray-400 focus:outline-none focus:border-accent transition"
                />
              </div>
              <div className="relative">
                <FiMapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  name="location"
                  value={filters.location}
                  onChange={handleChange}
                  placeholder="Location"
                  className="w-full bg-black/40 border border-white/20 rounded-xl py-3 pl-10 pr-4 text-white placeholder-gray-400 focus:outline-none focus:border-accent transition"
                />
              </div>
              <select
                name="type"
                value={filters.type}
                onChange={handleChange}
                className="bg-black/40 border border-white/20 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-accent"
              >
                <option value="">All vehicle types</option>
                <option value="car">🚗 Cars</option>
                <option value="bike">🏍️ Bikes</option>
              </select>
              <button
                type="button"
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="flex items-center justify-center gap-2 bg-white/10 rounded-xl py-3 text-gray-300 hover:text-white transition"
              >
                <FiSliders /> Advanced filters <FiChevronDown className={`transition-transform ${showAdvanced ? 'rotate-180' : ''}`} />
              </button>
            </div>

            <AnimatePresence>
              {showAdvanced && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden mt-4"
                >
                  <div className="pt-4 border-t border-white/10 grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Price Range Slider */}
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Price per day (£)</label>
                      <div className="flex gap-3">
                        <input
                          type="number"
                          name="minPrice"
                          value={filters.minPrice}
                          onChange={handleChange}
                          placeholder="Min"
                          className="w-full bg-black/40 border border-white/20 rounded-xl py-2 px-3 text-white"
                        />
                        <span className="text-gray-500 self-center">—</span>
                        <input
                          type="number"
                          name="maxPrice"
                          value={filters.maxPrice}
                          onChange={handleChange}
                          placeholder="Max"
                          className="w-full bg-black/40 border border-white/20 rounded-xl py-2 px-3 text-white"
                        />
                      </div>
                    </div>
                    {/* Date Range */}
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Select dates</label>
                      <DatePicker
                        startDate={filters.startDate}
                        endDate={filters.endDate}
                        onChange={(update) => setFilters({ ...filters, startDate: update[0], endDate: update[1] })}
                        className="w-full bg-black/40 border border-white/20 rounded-xl py-2 px-3 text-white"
                      />
                    </div>
                    <div className="flex items-end">
                      <Button type="submit" className="w-full bg-gradient-to-r from-accent to-orange-500 hover:shadow-lg transition-all">
                        <FiSearch className="inline mr-2" /> Search
                      </Button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {!showAdvanced && (
              <div className="flex justify-end mt-4">
                <Button type="submit" className="bg-gradient-to-r from-accent to-orange-500 hover:shadow-lg transition-all">
                  <FiSearch className="inline mr-2" /> Search
                </Button>
              </div>
            )}
          </form>

          {/* Active filter chips */}
          {hasActiveFilters && (
            <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-white/10">
              {Object.entries(filters).map(([key, val]) => {
                if (!val || key === 'startDate' || key === 'endDate') return null;
                let display = val;
                if (key === 'type') display = val === 'car' ? 'Car' : 'Bike';
                return (
                  <span key={key} className="bg-accent/20 text-accent text-sm px-3 py-1 rounded-full flex items-center gap-1">
                    {display}
                    <button onClick={() => removeFilter(key)} className="hover:text-white">
                      <FiX size={14} />
                    </button>
                  </span>
                );
              })}
              {(filters.startDate || filters.endDate) && (
                <span className="bg-accent/20 text-accent text-sm px-3 py-1 rounded-full flex items-center gap-1">
                  📅 {filters.startDate?.toLocaleDateString()} – {filters.endDate?.toLocaleDateString()}
                  <button onClick={() => removeFilter('startDate')} className="hover:text-white">
                    <FiX size={14} />
                  </button>
                </span>
              )}
              <button onClick={clearFilters} className="text-xs text-gray-400 hover:text-accent ml-auto">
                Clear all
              </button>
            </div>
          )}
        </div>

        {/* Results count */}
        <div className="flex justify-between items-center mb-6">
          <p className="text-gray-300">
            {!loading && pagination.total} vehicle{pagination.total !== 1 ? 's' : ''} found
          </p>
        </div>

        {/* Vehicle grid */}
        {loading ? (
          <div className="py-20 text-center"><Spinner size={50} color="#F59E0B" /></div>
        ) : vehicles.length === 0 ? (
          <EmptyState message="No vehicles match your filters. Try adjusting your search." />
        ) : (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              {vehicles.map((vehicle, idx) => (
                <motion.div
                  key={vehicle._id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  whileHover={{ y: -5 }}
                >
                  <VehicleCard vehicle={vehicle} />
                </motion.div>
              ))}
            </motion.div>
            <div className="mt-12">
              <Pagination
                page={pagination.page}
                pages={pagination.pages}
                onChange={(page) => setSearchParams({ ...Object.fromEntries(searchParams), page })}
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Search;

