import { useState, useRef } from 'react';
import { useAuth } from '../hooks/useAuth';
import api from '../api';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { FiUser, FiCamera, FiLock, FiSave, FiUpload } from 'react-icons/fi';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

const Profile = () => {
  const { user, login } = useAuth(); // login to refresh user context after avatar update
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [passwords, setPasswords] = useState({ currentPassword: '', newPassword: '' });
  const [avatarFile, setAvatarFile] = useState(null);
  const [avatarPreview, setAvatarPreview] = useState(null);
  const [loading, setLoading] = useState({ profile: false, password: false, avatar: false });
  const fileInputRef = useRef(null);

  // Default avatar fallback (using ui-avatars.com with user's name)
  const defaultAvatar = user?.name 
    ? `https://ui-avatars.com/api/?background=F59E0B&color=fff&name=${encodeURIComponent(user.name)}&size=128`
    : 'https://ui-avatars.com/api/?background=F59E0B&color=fff&name=User&size=128';

  const currentAvatar = avatarPreview || user?.avatarUrl || defaultAvatar;

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setLoading(prev => ({ ...prev, profile: true }));
    try {
      await api.put('/users/me', { name, phone });
      toast.success('Profile updated');
      // Optionally refresh user context (if you have a refetch method)
      window.location.reload(); // simple refresh to get updated user data
    } catch (err) { 
      toast.error(err.message); 
    } finally { 
      setLoading(prev => ({ ...prev, profile: false })); 
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    if (passwords.newPassword.length < 6) {
      toast.error('New password must be at least 6 characters');
      return;
    }
    setLoading(prev => ({ ...prev, password: true }));
    try {
      await api.put('/users/me/password', passwords);
      toast.success('Password changed. Please log in again.');
      localStorage.removeItem('token');
      window.location.href = '/login';
    } catch (err) { 
      toast.error(err.message); 
    } finally { 
      setLoading(prev => ({ ...prev, password: false })); 
    }
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image must be less than 5MB');
      return;
    }
    setAvatarFile(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      setAvatarPreview(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const handleAvatarUpload = async (e) => {
    e.preventDefault();
    if (!avatarFile) return;
    const formData = new FormData();
    formData.append('avatar', avatarFile);
    setLoading(prev => ({ ...prev, avatar: true }));
    try {
      const res = await api.post('/users/me/avatar', formData, { 
        headers: { 'Content-Type': 'multipart/form-data' } 
      });
      toast.success('Avatar updated');
      // Update user context with new avatar URL (if your AuthContext supports it)
      // For simplicity, reload the page to refresh user data
      window.location.reload();
    } catch (err) { 
      toast.error(err.message); 
    } finally { 
      setLoading(prev => ({ ...prev, avatar: false })); 
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-slate-900 to-black py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 text-center"
        >
          <h1 className="text-4xl md:text-5xl font-black bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
            My Profile
          </h1>
          <p className="text-gray-400 mt-2">Manage your personal information and security</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Avatar Card */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-1"
          >
            <div className="bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 p-6 text-center">
              <div className="relative inline-block">
                <img
                  src={currentAvatar}
                  alt="Profile"
                  className="w-32 h-32 rounded-full object-cover border-4 border-accent shadow-xl"
                />
                <label
                  htmlFor="avatar-upload"
                  className="absolute bottom-0 right-0 bg-accent hover:bg-accent-hover rounded-full p-2 cursor-pointer shadow-lg transition"
                >
                  <FiCamera className="text-white" size={16} />
                </label>
                <input
                  id="avatar-upload"
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarChange}
                  className="hidden"
                  ref={fileInputRef}
                />
              </div>
              <h2 className="text-xl font-bold text-white mt-4">{user?.name || 'User'}</h2>
              <p className="text-gray-400 text-sm">{user?.email}</p>
              <p className="text-gray-400 text-sm capitalize mt-1">Role: {user?.role || 'renter'}</p>

              {avatarFile && (
                <button
                  onClick={handleAvatarUpload}
                  disabled={loading.avatar}
                  className="mt-4 w-full bg-accent/20 hover:bg-accent/30 text-accent font-medium py-2 rounded-xl transition flex items-center justify-center gap-2"
                >
                  {loading.avatar ? <FiUpload className="animate-spin" /> : <FiUpload />}
                  {loading.avatar ? 'Uploading...' : 'Upload Avatar'}
                </button>
              )}
            </div>
          </motion.div>

          {/* Forms */}
          <div className="lg:col-span-2 space-y-6">
            {/* Personal Info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 p-6"
            >
              <h2 className="text-xl font-semibold text-white flex items-center gap-2 mb-4">
                <FiUser className="text-accent" /> Personal Information
              </h2>
              <form onSubmit={handleUpdateProfile} className="space-y-4">
                <Input
                  label="Full Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
                <Input
                  label="Phone Number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="Optional"
                />
                <Button
                  type="submit"
                  disabled={loading.profile}
                  className="w-full md:w-auto bg-gradient-to-r from-accent to-orange-500"
                >
                  {loading.profile ? 'Saving...' : <><FiSave className="inline mr-2" /> Update Profile</>}
                </Button>
              </form>
            </motion.div>

            {/* Change Password */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 p-6"
            >
              <h2 className="text-xl font-semibold text-white flex items-center gap-2 mb-4">
                <FiLock className="text-accent" /> Change Password
              </h2>
              <form onSubmit={handleChangePassword} className="space-y-4">
                <Input
                  label="Current Password"
                  type="password"
                  value={passwords.currentPassword}
                  onChange={(e) => setPasswords({ ...passwords, currentPassword: e.target.value })}
                  required
                />
                <Input
                  label="New Password"
                  type="password"
                  value={passwords.newPassword}
                  onChange={(e) => setPasswords({ ...passwords, newPassword: e.target.value })}
                  minLength={6}
                  required
                />
                <Button
                  type="submit"
                  disabled={loading.password}
                  variant="outline"
                  className="w-full md:w-auto"
                >
                  {loading.password ? 'Changing...' : 'Change Password'}
                </Button>
              </form>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;