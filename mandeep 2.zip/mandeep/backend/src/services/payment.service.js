const { paypalClient } = require('../config/payal');
const checkoutNodeJssdk = require('@paypal/checkout-server-sdk');
const Payment = require('../models/Payment');
const Booking = require('../models/Booking');

/**
 * Create a PayPal order for a booking deposit/full amount
 */
const createPayPalOrder = async (bookingId, userId) => {
  const booking = await Booking.findById(bookingId).populate('vehicleId');
  if (!booking) throw new Error('Booking not found');
  if (booking.renterId.toString() !== userId.toString()) throw new Error('Not authorized');
  if (booking.paymentStatus !== 'pending') throw new Error('Payment already initiated');

  const request = new checkoutNodeJssdk.orders.OrdersCreateRequest();
  request.headers['prefer'] = 'return=representation';
  request.body = {
    intent: 'CAPTURE',
    purchase_units: [
      {
        amount: {
          currency_code: 'USD',
          value: booking.totalPrice.toFixed(2),
        },
        description: `Booking for vehicle ${booking.vehicleId.title}`,
      },
    ],
  };

  const client = paypalClient();
  const order = await client.execute(request);

  // Save payment record
  await Payment.create({
    bookingId: booking._id,
    payerId: userId,
    payPalOrderId: order.result.id,
    amount: booking.totalPrice,
    currency: 'USD',
    status: 'created',
  });
  return order.result;
};

/**
 * Capture an approved PayPal order and update booking payment status
 */
const capturePayPalOrder = async (orderId, bookingId, userId) => {
  const booking = await Booking.findById(bookingId);
  if (!booking) throw new Error('Booking not found');
  const payment = await Payment.findOne({ bookingId, payPalOrderId: orderId });
  if (!payment) throw new Error('Payment record not found');
  if (booking.paymentStatus === 'paid') throw new Error('Payment already captured');

  // Verify order amount matches booking total
  const request = new checkoutNodeJssdk.orders.OrdersGetRequest(orderId);
  const client = paypalClient();
  const order = await client.execute(request);
  const capturedAmount = parseFloat(order.result.purchase_units[0].amount.value);
  if (capturedAmount !== booking.totalPrice) {
    throw new Error('Payment amount mismatch');
  }

  const captureRequest = new checkoutNodeJssdk.orders.OrdersCaptureRequest(orderId);
  const capture = await client.execute(captureRequest);

  payment.status = 'captured';
  payment.captureId = capture.result.purchase_units[0].payments.captures[0].id;
  await payment.save();

  booking.paymentStatus = 'paid';
  await booking.save();

  return { payment, booking };
};
module.exports = { createPayPalOrder, capturePayPalOrder };