import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  FiCalendar, FiCheckCircle, FiClock, FiMapPin, 
  FiDollarSign, FiArrowRight, FiAlertCircle, FiInfo
} from 'react-icons/fi';
import api from '../api';
import { formatCurrency, formatDate } from '../utils/helpers';
import Badge from '../components/ui/Badge';
import Spinner from '../components/ui/Spinner';
import EmptyState from '../components/ui/EmptyState';

// Helper functions for status descriptions
const getBookingStatusDescription = (status) => {
  switch(status) {
    case 'pending': return 'Awaiting owner approval';
    case 'accepted': return 'Approved – payment required';
    case 'completed': return 'Trip finished';
    case 'declined': return 'Request declined by owner';
    case 'cancelled': return 'Cancelled';
    default: return 'Unknown status';
  }
};

const getPaymentStatusDescription = (status) => {
  switch(status) {
    case 'pending': return 'Payment not made yet';
    case 'paid': return 'Payment completed';
    case 'refunded': return 'Money refunded';
    case 'failed': return 'Payment failed';
    default: return 'Unknown';
  }
};

const RenterDashboard = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchBookings = () => {
  api.get('/bookings/me')
    .then(res => setBookings(res?.data || []))
    .catch(err => console.error(err))
    .finally(() => setLoading(false));
};

useEffect(() => {
  setLoading(true);
  fetchBookings();

  const interval = setInterval(fetchBookings, 30000);

  const handleVisibilityChange = () => {
    if (document.visibilityState === 'visible') fetchBookings();
  };
  document.addEventListener('visibilitychange', handleVisibilityChange);

  return () => {
    clearInterval(interval);
    document.removeEventListener('visibilitychange', handleVisibilityChange);
  };
}, []);

  if (loading) return (
    <div className="flex justify-center items-center h-64">
      <Spinner size={50} color="#F59E0B" />
    </div>
  );

  const upcoming = bookings?.filter(b => ['pending', 'accepted'].includes(b.status)) || [];
  const completed = bookings?.filter(b => b.status === 'completed') || [];

  const stats = [
    { label: 'Upcoming / Pending', value: upcoming.length, icon: FiClock, color: 'from-blue-500/20 to-blue-600/20', borderColor: 'border-blue-500/30' },
    { label: 'Completed Trips', value: completed.length, icon: FiCheckCircle, color: 'from-green-500/20 to-emerald-600/20', borderColor: 'border-green-500/30' },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl md:text-4xl font-bold text-white">Renter Dashboard</h1>
        <p className="text-gray-400 mt-1">Track your bookings and upcoming trips</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        {stats.map((stat, idx) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            whileHover={{ y: -3, scale: 1.01 }}
            className={`relative overflow-hidden rounded-2xl bg-gradient-to-br ${stat.color} backdrop-blur-sm border ${stat.borderColor} shadow-xl transition-all duration-300`}
          >
            <div className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-200 text-sm uppercase tracking-wide">{stat.label}</p>
                  <p className="text-3xl md:text-4xl font-black text-white mt-1">{stat.value}</p>
                </div>
                <stat.icon className="text-4xl text-accent opacity-80" />
              </div>
            </div>
            <div className="absolute -top-10 -right-10 w-24 h-24 bg-white/5 rounded-full blur-2xl" />
          </motion.div>
        ))}
      </div>

      {/* Bookings List */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-white">Your Bookings</h2>
          {bookings.length > 0 && (
            <span className="text-sm text-gray-400">{bookings.length} total</span>
          )}
        </div>

        {bookings.length === 0 ? (
          <EmptyState message="You don't have any bookings yet. Start exploring vehicles!" />
        ) : (
          <div className="space-y-4">
            {bookings.map((booking, idx) => (
              <motion.div
                key={booking._id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                whileHover={{ y: -2 }}
                className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-5 hover:border-accent/30 transition-all"
              >
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                  {/* Left: Vehicle info */}
                  <div className="flex-1">
                    <h3 className="font-bold text-xl text-white group-hover:text-accent transition">
                      {booking.vehicleId?.title || 'Vehicle'}
                    </h3>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1 text-sm text-gray-300">
                      <span className="flex items-center gap-1">
                        <FiMapPin className="text-accent" size={14} />
                        {booking.vehicleId?.location || 'Location not specified'}
                      </span>
                      <span className="flex items-center gap-1">
                        <FiCalendar className="text-accent" size={14} />
                        {formatDate(booking.startDate)} – {formatDate(booking.endDate)}
                      </span>
                      <span className="flex items-center gap-1">
                        <FiDollarSign className="text-accent" size={14} />
                        {formatCurrency(booking.totalPrice)}
                      </span>
                    </div>

                    {/* Statuses with labels and tooltips */}
                    <div className="flex flex-wrap gap-4 mt-3">
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-400">Booking status:</span>
                        <Badge status={booking.status} />
                        <div className="relative group/tip">
                          <FiInfo className="text-gray-500 cursor-help" size={14} />
                          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-800 text-xs text-white rounded whitespace-nowrap opacity-0 group-hover/tip:opacity-100 transition pointer-events-none z-20">
                            {getBookingStatusDescription(booking.status)}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-400">Payment status:</span>
                        <Badge status={booking.paymentStatus} />
                        <div className="relative group/tip">
                          <FiInfo className="text-gray-500 cursor-help" size={14} />
                          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-800 text-xs text-white rounded whitespace-nowrap opacity-0 group-hover/tip:opacity-100 transition pointer-events-none z-20">
                            {getPaymentStatusDescription(booking.paymentStatus)}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right: Action button */}
                  <Link
                    to={`/vehicles/${booking.vehicleId?._id}`}
                    className="inline-flex items-center gap-1 text-accent hover:text-accent-hover font-medium text-sm transition group self-start"
                  >
                    View details
                    <FiArrowRight className="group-hover:translate-x-1 transition-transform" size={14} />
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Quick tip */}
      {bookings.length > 0 && (
        <div className="bg-accent/5 border border-accent/20 rounded-2xl p-4">
          <p className="text-gray-300 text-sm flex items-center gap-2">
            <FiAlertCircle className="text-accent" />
            <span>Need help? Contact support@wheelgo.com for any issues with your bookings.</span>
          </p>
        </div>
      )}
    </div>
  );
};
export default RenterDashboard;