import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import api from '../api';
import { calculateDays } from '../utils/helpers';
import DatePicker from './ui/DatePicker';
import Button from './ui/Button';
import toast from 'react-hot-toast';

const BookingForm = ({ vehicle }) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [dateRange, setDateRange] = useState([null, null]);
  const [startDate, endDate] = dateRange;
  const [loading, setLoading] = useState(false);

  const days = startDate && endDate ? calculateDays(startDate, endDate) : 0;
  const total = days * vehicle?.data?.pricePerDay;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user) {
      toast.error('Please log in to book');
      navigate('/login');
      return;
    }
    if (!startDate || !endDate || days <= 0) {
      toast.error('Select valid dates');
      return;
    }
    setLoading(true);
    try {
      await api.post('/bookings', {
        vehicleId: vehicle?.data?._id,
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
      });
      toast.success('Booking request sent!');
      navigate('/dashboard/rentals');
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-surface-light p-6 rounded-xl border border-surface-border">
      <h3 className="text-xl font-semibold mb-4 text-white">Book this vehicle</h3>
      <DatePicker label="Select dates" startDate={startDate} endDate={endDate} onChange={(update) => setDateRange(update)} />
      {days > 0 && (
        <div className="mb-4 p-3 bg-surface rounded-lg">
          <div className="flex justify-between text-sm">
            <span className="text-gray-300">{vehicle?.pricePerDay} × {days} day{days>1?'s':''}</span>
            <span className="text-accent font-bold">{total?.toFixed(2)}</span>
          </div>
        </div>
      )}
      <Button type="submit" disabled={loading} className="w-full mt-2">
        {loading ? 'Sending...' : 'Request Booking'}
      </Button>
    </form>
  );
};

export default BookingForm;