const Input = ({ label, error, ...props }) => (
  <div className="mb-4">
    {label && <label className="block text-sm font-medium mb-1 text-gray-300">{label}</label>}
    <input className="input-dark w-full" {...props} />
    {error && <p className="text-red-400 text-xs mt-1">{error}</p>}
  </div>
);
export default Input;