import { useParams, Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { 
  FiMapPin, FiCalendar, FiUsers, FiSettings, FiDroplet, FiUser, 
  FiStar, FiCheck, FiArrowLeft, FiShare2, FiHeart, FiShield,
  FiAward, FiThumbsUp, FiClock
} from 'react-icons/fi';
import api from '../api';
import ImageSlider from '../components/ui/ImageSlider';
import BookingForm from '../components/BookingForm';
import ReviewSection from '../components/ReviewsSection';
import Spinner from '../components/ui/Spinner';
import { useAuth } from '../hooks/useAuth';
import { formatCurrency } from '../utils/helpers';

const VehicleDetail = () => {
  const { id } = useParams();
  const [vehicle, setVehicle] = useState(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const [liked, setLiked] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
    api.get(`/vehicles/${id}`)
      .then(res => setVehicle(res))
      .catch(err => console.error(err))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-slate-900 to-black">
      <Spinner size={60} color="#F59E0B" />
    </div>
  );
  
  if (!vehicle) return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-gray-900 to-black">
      <p className="text-gray-400 text-lg mb-4">Vehicle not found</p>
      <Link to="/search" className="text-accent hover:underline">← Back to search</Link>
    </div>
  );

  const vehicleData = vehicle.data || vehicle;
  const isOwner = user && vehicleData?.ownerId?._id === user.id;
  const canReview = user && !isOwner && vehicleData?.bookings?.some(b => b.status === 'completed' && b.renterId === user?._id);
  const bookingIdForReview = canReview ? vehicleData.bookings?.find(b => b.status === 'completed')?._id : null;

  const specs = [
    { icon: FiUsers, label: 'Seats', value: vehicleData.seats || 'N/A', color: 'from-blue-500/20 to-blue-600/20' },
    { icon: FiSettings, label: 'Transmission', value: vehicleData.transmission ? vehicleData.transmission.charAt(0).toUpperCase() + vehicleData.transmission.slice(1) : 'N/A', color: 'from-green-500/20 to-emerald-600/20' },
    { icon: FiDroplet, label: 'Fuel', value: vehicleData.fuelType ? vehicleData.fuelType.charAt(0).toUpperCase() + vehicleData.fuelType.slice(1) : 'N/A', color: 'from-orange-500/20 to-amber-600/20' },
    { icon: FiCalendar, label: 'Year', value: vehicleData.year || 'N/A', color: 'from-purple-500/20 to-violet-600/20' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-slate-900 to-black">
      {/* Animated background blobs */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      {/* Sticky top bar with actions */}
      <div className="sticky top-0 z-30 bg-black/40 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center">
          <Link to="/search" className="inline-flex items-center gap-2 text-gray-300 hover:text-accent transition-colors">
            <FiArrowLeft /> Back to search
          </Link>
          <div className="flex gap-3">
            <button onClick={() => setLiked(!liked)} className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition">
              <FiHeart className={liked ? 'text-red-500 fill-red-500' : 'text-gray-300'} size={18} />
            </button>
            <button className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition">
              <FiShare2 className="text-gray-300" size={18} />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left column */}
          <div className="lg:col-span-2 space-y-8">
            {/* Image Slider with rounded corners and shadow */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="rounded-3xl overflow-hidden shadow-2xl shadow-black/30"
            >
              <ImageSlider images={vehicleData?.images} />
            </motion.div>

            {/* Title and price row with badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="flex flex-col sm:flex-row sm:justify-between sm:items-start gap-4"
            >
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="bg-accent/20 text-accent text-xs px-2 py-0.5 rounded-full">Available now</span>
                  {vehicleData.averageRating > 0 && (
                    <span className="bg-green-500/20 text-green-400 text-xs px-2 py-0.5 rounded-full flex items-center gap-1">
                      <FiThumbsUp size={10} /> Top rated
                    </span>
                  )}
                </div>
                <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight">{vehicleData.title}</h1>
                <div className="flex flex-wrap items-center gap-3 mt-3 text-gray-300">
                  <span className="capitalize flex items-center gap-1 text-sm">
                    {vehicleData.vehicleType === 'car' ? '🚗' : '🏍️'} {vehicleData.vehicleType}
                  </span>
                  <span className="flex items-center gap-1 text-sm"><FiMapPin /> {vehicleData.location}</span>
                </div>
              </div>
              <div className="bg-gradient-to-br from-accent/10 to-orange-500/10 rounded-2xl px-6 py-4 text-center backdrop-blur-sm border border-accent/20">
                <div className="text-4xl font-black text-accent">{formatCurrency(vehicleData.pricePerDay)}<span className="text-sm text-gray-400">/day</span></div>
                {vehicleData.averageRating > 0 && (
                  <div className="flex items-center justify-center gap-1 mt-1 text-sm">
                    <FiStar className="text-accent fill-accent" /> {vehicleData.averageRating.toFixed(1)} ({vehicleData.totalReviews || 0} reviews)
                  </div>
                )}
              </div>
            </motion.div>

            {/* Description with gradient background */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="relative bg-gradient-to-br from-white/5 to-white/0 backdrop-blur-sm rounded-3xl p-8 border border-white/10 shadow-xl overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-64 h-64 bg-accent/5 rounded-full blur-3xl" />
              <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2"><FiShield /> Description</h2>
              <p className="text-gray-300 leading-relaxed text-lg">{vehicleData.description || 'No description provided.'}</p>
            </motion.div>

            {/* Specifications with beautiful cards */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-gradient-to-br from-white/5 to-white/0 backdrop-blur-sm rounded-3xl p-8 border border-white/10"
            >
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2"><FiAward /> Key Specifications</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {specs.map((spec, idx) => (
                  <div key={idx} className={`group relative bg-gradient-to-br ${spec.color} rounded-2xl p-5 text-center border border-white/10 hover:border-accent/40 transition-all duration-300 hover:-translate-y-1`}>
                    <spec.icon className="text-accent text-3xl mx-auto mb-3 group-hover:scale-110 transition-transform" />
                    <p className="text-gray-300 text-sm uppercase tracking-wide">{spec.label}</p>
                    <p className="text-white font-bold text-xl mt-1">{spec.value}</p>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Owner card with enhanced style */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-gradient-to-br from-white/5 to-white/0 backdrop-blur-sm rounded-3xl p-8 border border-white/10"
            >
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2"><FiUser /> Meet your host</h2>
              <div className="flex flex-col sm:flex-row items-center gap-6">
                <div className="relative">
                  <img
                    src={vehicleData.ownerId?.avatarUrl || `https://ui-avatars.com/api/?background=F59E0B&color=fff&name=${vehicleData.ownerId?.name || 'Owner'}`}
                    alt={vehicleData.ownerId?.name}
                    className="w-24 h-24 rounded-full object-cover border-4 border-accent shadow-lg"
                  />
                  <div className="absolute bottom-0 right-0 bg-green-500 rounded-full p-1 border-2 border-white">
                    <FiCheck className="text-white" size={12} />
                  </div>
                </div>
                <div className="text-center sm:text-left">
                  <p className="text-white font-bold text-2xl">{vehicleData.ownerId?.name || 'Vehicle Owner'}</p>
                  <p className="text-gray-300 flex items-center justify-center sm:justify-start gap-1 mt-1"><FiShield className="text-accent" /> Verified member since 2024</p>
                  <div className="flex items-center gap-4 mt-3 text-sm text-gray-400">
                    <span className="flex items-center gap-1"><FiThumbsUp /> 98% response rate</span>
                    <span className="flex items-center gap-1"><FiClock /> Responds within 1 hour</span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Reviews Section */}
            <ReviewSection 
              vehicleId={vehicleData._id} 
              bookingId={bookingIdForReview} 
              canReview={canReview} 
            />
          </div>

          {/* Right column: Booking form – premium styled */}
          <div className="lg:sticky lg:top-24 self-start">
  <div className="bg-gradient-to-br from-gray-800/80 via-gray-900/80 to-black/80 backdrop-blur-xl rounded-2xl border border-white/20 shadow-2xl">
    <div className="p-5 border-b border-white/10 bg-white/5">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-bold text-white">Book this vehicle</h3>
          <p className="text-gray-300 text-xs mt-1">Secure · Instant confirmation</p>
        </div>
        <div className="bg-accent/20 rounded-full px-3 py-1">
          <span className="text-accent font-bold text-sm">{formatCurrency(vehicleData.pricePerDay)}<span className="text-xs">/day</span></span>
        </div>
      </div>
    </div>
    <div className="p-5">
      <BookingForm vehicle={{ data: vehicleData }} />
    </div>
  </div>
</div>
        </div>
      </div>
    </div>
  );
};

export default VehicleDetail;
