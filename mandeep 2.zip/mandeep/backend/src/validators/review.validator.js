const { body } = require('express-validator');

const createReviewRules = [
  body('bookingId').isMongoId().withMessage('Valid booking ID required'),
  body('rating').isInt({ min: 1, max: 5 }).withMessage('Rating must be between 1 and 5'),
  body('comment').optional().isString().trim().isLength({ max: 500 }),
];
module.exports = { createReviewRules };