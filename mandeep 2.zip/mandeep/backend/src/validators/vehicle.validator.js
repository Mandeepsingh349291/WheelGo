const { body } = require('express-validator');

const createVehicleRules = [
  body('title').trim().notEmpty().withMessage('Title is required'),
  body('vehicleType').isIn(['car', 'bike']).withMessage('Type must be car or bike'),
  body('pricePerDay').isFloat({ min: 0 }).withMessage('Price per day must be a positive number'),
  body('location').trim().notEmpty().withMessage('Location is required'),
  body('seats').optional().isInt({ min: 1 }).withMessage('Seats must be at least 1'),
  body('transmission').optional().isIn(['automatic', 'manual']),
  body('fuelType').optional().isIn(['petrol', 'diesel', 'electric', 'hybrid']),
];

const updateVehicleRules = [
  body('title').optional().trim().notEmpty().withMessage('Title cannot be empty'),
  body('pricePerDay').optional().isFloat({ min: 0 }).withMessage('Price per day must be a positive number'),
  // ... similar optional validation
];

module.exports = { createVehicleRules, updateVehicleRules };
