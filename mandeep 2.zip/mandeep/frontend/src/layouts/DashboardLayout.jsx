import { Outlet, NavLink } from 'react-router-dom';
import Navbar from './Navbar';
import { useAuth } from '../hooks/useAuth';

const DashboardLayout = () => {
  const { user } = useAuth();
  const role = user?.role;

  const links = [];
  if (role === 'renter') {
    links.push({ to: '/dashboard', label: 'Dashboard', end: true });
    links.push({ to: '/dashboard/rentals', label: 'My Rentals' });
  } else if (role === 'owner') {
    links.push({ to: '/dashboard', label: 'Dashboard', end: true });
    links.push({ to: '/dashboard/listings', label: 'My Listings' });
    links.push({ to: '/dashboard/requests', label: 'Booking Requests' });
    links.push({ to: '/dashboard/rentals', label: 'My Rentals' });
  } else if (role === 'admin') {
    links.push({ to: '/dashboard', label: 'Dashboard', end: true });
    links.push({ to: '/dashboard/admin/users', label: 'Users' });
    links.push({ to: '/dashboard/admin/listings', label: 'Listings' });
    links.push({ to: '/dashboard/admin/bookings', label: 'Bookings' });
  }
  links.push({ to: '/profile', label: 'Profile' });

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <div className="flex-1 flex">
        <aside className="w-64 bg-surface-light border-r border-surface-border p-6 hidden md:block">
          <h2 className="text-xl font-bold text-white mb-6">Dashboard</h2>
          <nav className="space-y-2">
            {links.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.end}
                className={({ isActive }) =>
                  `block px-4 py-2 rounded-lg text-sm font-medium ${
                    isActive ? 'bg-accent text-white' : 'text-gray-300 hover:bg-surface-border'
                  }`
                }
              >
                {link.label}
              </NavLink>
            ))}
          </nav>
        </aside>
        <main className="flex-1 p-6 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
