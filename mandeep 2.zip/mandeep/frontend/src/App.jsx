import { Routes, Route } from 'react-router-dom';
import MainLayout from './layouts/MainLayout';
import DashboardLayout from './layouts/DashboardLayout';
import ProtectedRoute from './components/ProtectedRoute'; // we need this
import RoleRoute from './components/RoleRoute'; // simplified, can be inside ProtectedRoute

// For simplicity, we'll define ProtectedRoute inline or import from a file.
// Let's create a ProtectedRoute component in components/ProtectedRoute.jsx
// and RoleRoute.

import Home from './pages/Home';
import Search from './pages/Search';
import VehicleDetail from './pages/VehicleDetail';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
import Dashboard from './pages/Dashboard';
import OwnerListings from './pages/OwnerListings';
import OwnerBookingRequests from './pages/OwnerBookingRequests';
import MyRentals from './pages/MyRentals';
import CreateEditListing from './pages/CreateEditListing';
import AdminDashboard from './pages/AdminDashboard';
import NotFound from './pages/NotFound';
import PaymentSuccess from './pages/PaymentSuccess';
import PaymentCancel from './pages/PaymentCancel';
import PublicOnly from './components/PublicOnly'
const App = () => (
  <Routes>
    <Route element={<MainLayout />}>
      <Route path="/" element={<Home />} />
      <Route path="/search" element={<Search />} />
      <Route path="/vehicles/:id" element={<VehicleDetail />} />
      <Route path="/payment/success" element={<PaymentSuccess />} />
      <Route path="/payment/cancel" element={<PaymentCancel />} />
      <Route path="/login" element={<PublicOnly><Login /></PublicOnly>} />
      <Route path="/register" element={<PublicOnly><Register /></PublicOnly>} />
      <Route path="*" element={<NotFound />} />
    </Route>

    <Route element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/profile" element={<Profile />} />
      {/* Renter / Owner both can see rentals */}
      <Route path="/dashboard/rentals" element={<MyRentals />} />
      {/* Owner specific */}
      <Route path="/dashboard/listings" element={<RoleRoute allowedRoles={['owner']}><OwnerListings /></RoleRoute>} />
      <Route path="/dashboard/listings/new" element={<RoleRoute allowedRoles={['owner']}><CreateEditListing /></RoleRoute>} />
      <Route path="/dashboard/listings/:id/edit" element={<RoleRoute allowedRoles={['owner']}><CreateEditListing /></RoleRoute>} />
      <Route path="/dashboard/requests" element={<RoleRoute allowedRoles={['owner']}><OwnerBookingRequests /></RoleRoute>} />
      {/* Admin */}
      <Route path="/dashboard/admin/*" element={<RoleRoute allowedRoles={['admin']}><AdminDashboard /></RoleRoute>} />
    </Route>
  </Routes>
);

export default App;