const router = require('express').Router();
const { searchVehicles } = require('../controllers/search.controller');

router.get('/', searchVehicles);

module.exports = router;