const bcrypt = require('bcryptjs');

const hashPassword = async (plain) => {
  return bcrypt.hash(plain, 12);
};

const comparePassword = async (plain, hash) => {
  return bcrypt.compare(plain, hash);
};
module.exports = { hashPassword, comparePassword };