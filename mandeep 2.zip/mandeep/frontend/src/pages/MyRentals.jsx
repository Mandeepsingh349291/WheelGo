import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FiCalendar, FiMapPin, FiDollarSign, FiStar, 
  FiArrowRight, FiClock, FiCheckCircle, FiAlertCircle,
  FiCreditCard, FiUser, FiTruck, FiInfo
} from 'react-icons/fi';
import api from '../api';
import { formatDate, calculateDays, formatCurrency } from '../utils/helpers';
import Badge from '../components/ui/Badge';
import PayPalButton from '../components/ui/PayPalButton';
import Spinner from '../components/ui/Spinner';
import EmptyState from '../components/ui/EmptyState';

const MyRentals = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchBookings = () => {
  api.get('/bookings/me')
    .then(res => setBookings(res?.data || []))
    .catch(err => console.error(err))
    .finally(() => setLoading(false));
};

useEffect(() => {
  setLoading(true);
  fetchBookings();

  // Poll every 30s for status updates
  const interval = setInterval(fetchBookings, 30000);

  // Refetch when user comes back to this tab
  const handleVisibilityChange = () => {
    if (document.visibilityState === 'visible') fetchBookings();
  };
  document.addEventListener('visibilitychange', handleVisibilityChange);

  return () => {
    clearInterval(interval);
    document.removeEventListener('visibilitychange', handleVisibilityChange);
  };
}, []);

  useEffect(() => {
    fetchBookings();
  }, []);

  if (loading) return (
    <div className="flex justify-center items-center h-96">
      <div className="relative">
        <div className="absolute inset-0 bg-accent/20 rounded-full blur-xl animate-pulse" />
        <Spinner size={60} color="#F59E0B" />
      </div>
    </div>
  );
  
  if (bookings?.length === 0) return (
    <div className="flex flex-col items-center justify-center py-20">
      <div className="bg-white/5 rounded-full p-6 mb-4">
        <FiTruck className="text-5xl text-accent" />
      </div>
      <EmptyState message="You have no rentals yet. Start exploring vehicles!" />
      <Link to="/search" className="mt-4 inline-flex items-center gap-2 text-accent hover:gap-3 transition-all">
        Browse vehicles <FiArrowRight />
      </Link>
    </div>
  );

  // Helper to get human-friendly status descriptions
  const getBookingStatusDescription = (status) => {
    switch(status) {
      case 'pending': return 'Awaiting owner approval';
      case 'accepted': return 'Approved – payment required';
      case 'completed': return 'Trip finished';
      case 'declined': return 'Request declined by owner';
      case 'cancelled': return 'Cancelled';
      default: return 'Unknown status';
    }
  };

  const getPaymentStatusDescription = (status) => {
    switch(status) {
      case 'pending': return 'Payment not made yet';
      case 'paid': return 'Payment completed';
      case 'refunded': return 'Money refunded';
      case 'failed': return 'Payment failed';
      default: return 'Unknown';
    }
  };

  return (
    <div className="relative">
      <div className="absolute inset-0 bg-gradient-to-br from-accent/5 via-transparent to-primary/5 pointer-events-none" />
      
      <div className="relative z-10 space-y-8">
        {/* Header */}
        <div className="relative">
          <h1 className="text-4xl md:text-5xl font-black bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
            My Rentals
          </h1>
          <div className="absolute -bottom-2 left-0 w-20 h-1 bg-gradient-to-r from-accent to-transparent rounded-full" />
          <p className="text-gray-400 mt-4 text-lg">Manage your bookings and payments</p>
        </div>

        {/* Stats summary */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white/5 backdrop-blur rounded-2xl p-4 border border-white/10">
            <p className="text-gray-400 text-sm">Active / Upcoming</p>
            <p className="text-2xl font-bold text-white">{bookings.filter(b => ['pending','accepted'].includes(b.status)).length}</p>
          </div>
          <div className="bg-white/5 backdrop-blur rounded-2xl p-4 border border-white/10">
            <p className="text-gray-400 text-sm">Total Spent</p>
            <p className="text-2xl font-bold text-accent">{formatCurrency(bookings.reduce((sum, b) => sum + (b.totalPrice || 0), 0))}</p>
          </div>
        </div>

        {/* Bookings list */}
        <div className="space-y-5">
          <AnimatePresence>
            {bookings.map((booking, idx) => (
              <motion.div
                key={booking._id}
                initial={{ opacity: 0, y: 30, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: idx * 0.08, type: "spring", stiffness: 300, damping: 25 }}
                whileHover={{ y: -6 }}
                className="relative group bg-gradient-to-br from-gray-800/60 to-gray-900/60 backdrop-blur-xl rounded-3xl border border-white/10 shadow-2xl overflow-hidden transition-all duration-300"
              >
                {/* Shine effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />

                <div className="p-6 md:p-7">
                  <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-5">
                    {/* Left side */}
                    <div className="flex-1 space-y-3">
                      <h3 className="text-2xl font-bold text-white group-hover:text-accent transition-colors duration-200">
                        {booking.vehicleId?.title || 'Vehicle'}
                      </h3>

                      {/* Statuses with labels and tooltips */}
                      <div className="flex flex-wrap gap-4">
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-400">Booking status:</span>
                          <Badge status={booking.status} />
                          <div className="relative group/tip">
                            <FiInfo className="text-gray-500 cursor-help" size={14} />
                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-800 text-xs text-white rounded whitespace-nowrap opacity-0 group-hover/tip:opacity-100 transition pointer-events-none">
                              {getBookingStatusDescription(booking.status)}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-400">Payment status:</span>
                          <Badge status={booking.paymentStatus} />
                          <div className="relative group/tip">
                            <FiInfo className="text-gray-500 cursor-help" size={14} />
                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-800 text-xs text-white rounded whitespace-nowrap opacity-0 group-hover/tip:opacity-100 transition pointer-events-none">
                              {getPaymentStatusDescription(booking.paymentStatus)}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Details grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-gray-300">
                        <div className="flex items-center gap-2 bg-white/5 rounded-xl px-3 py-2">
                          <FiCalendar className="text-accent" />
                          <span className="text-sm">{formatDate(booking.startDate)} – {formatDate(booking.endDate)}</span>
                          <span className="text-xs text-gray-500">({calculateDays(booking.startDate, booking.endDate)} days)</span>
                        </div>
                        <div className="flex items-center gap-2 bg-white/5 rounded-xl px-3 py-2">
                          <FiMapPin className="text-accent" />
                          <span className="text-sm truncate">{booking.vehicleId?.location || 'N/A'}</span>
                        </div>
                        <div className="flex items-center gap-2 bg-white/5 rounded-xl px-3 py-2">
                          <FiDollarSign className="text-accent" />
                          <span className="text-sm font-semibold text-accent">{formatCurrency(booking.totalPrice)}</span>
                          <span className="text-xs text-gray-400">total</span>
                        </div>
                        <div className="flex items-center gap-2 bg-white/5 rounded-xl px-3 py-2">
                          <FiUser className="text-accent" />
                          <span className="text-sm">Owner: {booking.ownerId?.name || 'N/A'}</span>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-row lg:flex-col gap-3 lg:min-w-[200px]">
                      {booking.status === 'accepted' && booking.paymentStatus === 'pending' && (
                        <div className="w-full">
                          <PayPalButton 
                            bookingId={booking._id} 
                            amount={booking.totalPrice} 
                            onSuccess={fetchBookings} 
                          />
                        </div>
                      )}
                      {booking.status === 'completed' && !booking.reviewed && (
                        <Link
                          to={`/vehicles/${booking.vehicleId?._id}`}
                          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-accent to-orange-500 hover:shadow-lg text-white rounded-xl transition-all font-medium text-sm"
                        >
                          <FiStar /> Leave a Review
                        </Link>
                      )}
                      {booking.status !== 'completed' && booking.paymentStatus !== 'pending' && (
                        <Link
                          to={`/vehicles/${booking.vehicleId?._id}`}
                          className="inline-flex items-center justify-center gap-1 text-gray-400 hover:text-accent text-sm transition group"
                        >
                          View vehicle details
                          <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
                        </Link>
                      )}
                      {booking.status === 'pending' && (
                        <div className="text-xs text-gray-400 flex items-center gap-1 justify-center lg:justify-start">
                          <FiClock className="text-yellow-500" /> Waiting for owner
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Extra info */}
                  {booking.status === 'declined' && (
                    <div className="mt-4 pt-3 border-t border-white/10 text-sm text-red-300 flex items-center gap-2">
                      <FiAlertCircle /> This booking was declined by the owner.
                    </div>
                  )}
                  {booking.status === 'accepted' && booking.paymentStatus === 'paid' && (
                    <div className="mt-4 pt-3 border-t border-white/10 text-sm text-emerald-300 flex items-center gap-2">
                      <FiCheckCircle /> Payment confirmed. You're all set for pickup!
                    </div>
                  )}
                </div>

                <div className="absolute bottom-0 right-0 w-24 h-24 bg-gradient-to-tl from-accent/10 to-transparent rounded-tl-full pointer-events-none" />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
export default MyRentals;