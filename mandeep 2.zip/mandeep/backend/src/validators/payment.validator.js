const { body } = require('express-validator');

const createOrderRules = [
  body('bookingId').isMongoId().withMessage('Valid booking ID required'),
];

const captureOrderRules = [
  body('orderId').notEmpty().withMessage('PayPal order ID is required'),
  body('bookingId').isMongoId().withMessage('Valid booking ID is required'),
];

module.exports = { createOrderRules, captureOrderRules };