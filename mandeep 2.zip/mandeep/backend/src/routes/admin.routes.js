const router = require('express').Router();
const protect = require('../middleware/auth.middleware');
const authorize = require('../middleware/role.middleware');
const adminController = require('../controllers/admin.controller');

router.use(protect, authorize('admin'));
router.get('/dashboard', adminController.getDashboard);
router.get('/users', adminController.getUsers);
router.get('/vehicles', adminController.getVehicles);
router.patch('/vehicles/:id/moderate', adminController.moderateVehicle);
router.get('/bookings', adminController.getBookings);
router.get('/reports', adminController.getReports);
router.patch('/reports/:id', adminController.resolveReport);
router.patch('/users/:id/status', adminController.updateUserStatus);
router.patch('/bookings/:id/payment-status', adminController.updateBookingPaymentStatus);
module.exports = router;