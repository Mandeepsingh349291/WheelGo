import { useAuth } from '../hooks/useAuth';
import RenterDashboard from './RenterDashboard'; // we'll create a separate file or combine
import OwnerDashboard from './OwnerDashboard';
import AdminDashboard from './AdminDashboard';

const Dashboard = () => {
  const { user } = useAuth();
  if (!user) return null;
  switch (user.role) {
    case 'owner': return <OwnerDashboard />;
    case 'admin': return <AdminDashboard />;
    case 'renter': default: return <RenterDashboard />;
  }
};

export default Dashboard;