import { useState, useEffect } from 'react';
import api from '../api';
import StarRating from './ui/StarRating';
import Button from './ui/Button';
import toast from 'react-hot-toast';
import { formatDate } from '../utils/helpers';

const ReviewSection = ({ vehicleId, bookingId, canReview }) => {
  const [reviews, setReviews] = useState([]);
  const [newReview, setNewReview] = useState({ rating: 0, comment: '' });
  const [loading, setLoading] = useState(false);

  const fetchReviews = async () => {
    try {
      const res = await api.get(`/reviews/vehicle/${vehicleId}`);
      setReviews(res);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => { fetchReviews(); }, [vehicleId]);

  const handleSubmitReview = async (e) => {
    e.preventDefault();
    if (newReview?.rating === 0) { toast.error('Please select a rating'); return; }
    setLoading(true);
    try {
      await api.post('/reviews', { bookingId, rating: newReview.rating, comment: newReview.comment });
      toast.success('Review submitted!');
      setNewReview({ rating: 0, comment: '' });
      fetchReviews();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-10">
      <h2 className="text-2xl font-semibold mb-4 text-white">Reviews</h2>
      {canReview && (
        <form onSubmit={handleSubmitReview} className="bg-surface-light p-4 rounded-lg mb-6 border border-surface-border">
          <div className="flex items-center space-x-4 mb-3">
            <StarRating rating={newReview?.rating} onRate={(r) => setNewReview({...newReview, rating: r})} editable />
          </div>
          <textarea
            className="input-dark w-full mb-3"
            rows={3}
            placeholder="Write your experience..."
            value={newReview?.comment}
            onChange={(e) => setNewReview({...newReview, comment: e.target.value})}
          />
          <Button type="submit" disabled={loading}>{loading ? 'Submitting...' : 'Submit Review'}</Button>
        </form>
      )}
      {reviews?.length === 0 ? (
        <p className="text-gray-400">No reviews yet.</p>
      ) : (
        reviews?.data?.map((review) => (
          <div key={review?._id} className="bg-surface-light p-4 rounded-lg mb-3 border border-surface-border">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center space-x-2">
                <img src={review?.reviewerId?.avatarUrl || '/assets/images/default-avatar.png'} alt="" className="h-8 w-8 rounded-full" />
                <span className="font-medium text-sm">{review?.reviewerId?.name || 'User'}</span>
              </div>
              <span className="text-xs text-gray-400">{formatDate(review?.createdAt)}</span>
            </div>
            <StarRating rating={review?.rating} editable={false} />
            {review?.comment && <p className="text-sm text-gray-300 mt-1">{review?.comment}</p>}
          </div>
        ))
      )}
    </div>
  );
};

export default ReviewSection;
