const Booking = require('../models/Booking');
const bookingService = require('../services/booking.service');
const notificationService = require('../services/notification.service');
const { successResponse } = require('../utils/response');

/**
 * Create a new booking request.
 * POST /api/bookings
 */
const createBooking = async (req, res, next) => {
  try {
    const { vehicleId, startDate, endDate } = req.body;
    const booking = await bookingService.createBookingRequest(
      req.user.id,
      vehicleId,
      new Date(startDate),
      new Date(endDate)
    );

    // Notify the vehicle owner about the new request
    await notificationService.createNotification(
      booking.ownerId,
      'booking_request',
      'New Booking Request',
      `You have a new booking request for your vehicle.`,
      { bookingId: booking._id }
    );

    successResponse(res, booking, 'Booking request created', 201);
  } catch (err) {
    next(err);
  }
};

/**
 * Get bookings for the logged-in renter.
 * GET /api/bookings/me
 */
const getRenterBookings = async (req, res, next) => {
  try {
    const bookings = await Booking.find({ renterId: req.user.id })
      .populate('vehicleId', 'title images pricePerDay location vehicleType')
      .populate('ownerId', 'name email avatarUrl')
      .sort('-createdAt');

    successResponse(res, bookings);
  } catch (err) {
    next(err);
  }
};

/**
 * Get bookings for the logged-in owner.
 * GET /api/bookings/owner
 */
const getOwnerBookings = async (req, res, next) => {
  try {
    const bookings = await Booking.find({ ownerId: req.user.id })
      .populate('renterId', 'name email avatarUrl phone')
      .populate('vehicleId', 'title images pricePerDay')
      .sort('-createdAt');

    successResponse(res, bookings);
  } catch (err) {
    next(err);
  }
};

/**
 * Accept a booking request (owner action).
 * PATCH /api/bookings/:id/accept
 */
const acceptBooking = async (req, res, next) => {
  try {
    const booking = await bookingService.acceptBooking(req.params.id, req.user.id);

    // Notify the renter
    await notificationService.createNotification(
      booking.renterId,
      'booking_accepted',
      'Booking Accepted',
      `Your booking for "${booking.vehicleId?.title || 'vehicle'}" has been accepted.`,
      { bookingId: booking._id }
    );

    successResponse(res, booking, 'Booking accepted');
  } catch (err) {
    next(err);
  }
};

/**
 * Decline a booking request (owner action).
 * PATCH /api/bookings/:id/decline
 */
const declineBooking = async (req, res, next) => {
  try {
    const { reason } = req.body || {};
    const booking = await bookingService.declineBooking(req.params.id, req.user.id, reason);

    // Notify the renter
    await notificationService.createNotification(
      booking.renterId,
      'booking_declined',
      'Booking Declined',
      `Your booking request has been declined. ${reason ? `Reason: ${reason}` : ''}`,
      { bookingId: booking._id }
    );

    successResponse(res, booking, 'Booking declined');
  } catch (err) {
    next(err);
  }
};

/**
 * Cancel a booking (renter action).
 * PATCH /api/bookings/:id/cancel
 */
const cancelBooking = async (req, res, next) => {
  try {
    const booking = await bookingService.cancelBooking(req.params.id, req.user.id, req.user.role);

    await notificationService.createNotification(
      booking.ownerId,
      'booking_cancelled',
      'Booking Cancelled',
      `A booking for your vehicle has been cancelled${req.user.role === 'admin' ? ' by admin' : ' by the renter'}.`,
      { bookingId: booking._id }
    );
    successResponse(res, booking, 'Booking cancelled');
  } catch (err) {
    next(err);
  }
};

/**
 * Mark a booking as completed (owner action).
 * PATCH /api/bookings/:id/complete
 */
const markCompleted = async (req, res, next) => {
  try {
    const booking = await bookingService.markCompleted(req.params.id, req.user.id);

    // Notify the renter that the booking is complete
    await notificationService.createNotification(
      booking.renterId,
      'booking_completed',
      'Booking Completed',
      `Your booking has been marked as completed. You can now leave a review.`,
      { bookingId: booking._id }
    );

    successResponse(res, booking, 'Booking marked as completed');
  } catch (err) {
    next(err);
  }
};

module.exports = {
  createBooking,
  getRenterBookings,
  getOwnerBookings,
  acceptBooking,
  declineBooking,
  cancelBooking,
  markCompleted,
};