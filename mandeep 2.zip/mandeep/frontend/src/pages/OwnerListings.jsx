import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { FiEdit, FiTrash2, FiPlus, FiMapPin, FiDollarSign, FiEye, FiInfo } from 'react-icons/fi';
import api from '../api';
import { formatCurrency } from '../utils/helpers';
import Button from '../components/ui/Button';
import Spinner from '../components/ui/Spinner';
import EmptyState from '../components/ui/EmptyState';
import toast from 'react-hot-toast';

// Helper for status description
const getVehicleStatusDescription = (status) => {
  switch(status) {
    case 'active': return 'Visible to renters and available for booking';
    case 'inactive': return 'Hidden from search – no new bookings possible';
    default: return 'Unknown status';
  }
};

const OwnerListings = () => {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchListings = async () => {
    try {
      const res = await api.get('/vehicles?owner=me');
      setListings(res?.data?.vehicles || []);
    } catch (err) { 
      toast.error(err.message); 
    } finally { 
      setLoading(false); 
    }
  };

  useEffect(() => { fetchListings(); }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this listing? This action cannot be undone.')) return;
    try {
      await api.delete(`/vehicles/${id}`);
      toast.success('Listing deleted');
      fetchListings();
    } catch (err) { 
      toast.error(err.message); 
    }
  };

  if (loading) return (
    <div className="flex justify-center items-center h-64">
      <Spinner size={50} color="#F59E0B" />
    </div>
  );

  if (listings.length === 0) {
    return (
      <div className="text-center py-12">
        <EmptyState message="No listings yet. Create your first vehicle!" />
        <Link to="/dashboard/listings/new" className="inline-block mt-4">
          <Button className="bg-accent hover:bg-accent-hover">+ Add Vehicle</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold text-white">My Listings</h1>
          <p className="text-gray-400 mt-1">Manage your vehicles – edit, update, or remove</p>
        </div>
        <Link to="/dashboard/listings/new">
          <Button className="bg-gradient-to-r from-accent to-orange-500 hover:shadow-lg transition-all flex items-center gap-2">
            <FiPlus /> Add Vehicle
          </Button>
        </Link>
      </div>

      {/* Listings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {listings.map((vehicle, idx) => (
          <motion.div
            key={vehicle._id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            whileHover={{ y: -5 }}
            className="group relative bg-gradient-to-br from-gray-800/80 to-gray-900/80 backdrop-blur-sm rounded-2xl border border-white/10 overflow-hidden shadow-xl hover:shadow-2xl hover:border-accent/40 transition-all duration-300"
          >
            {/* Image container with overlay */}
            <div className="relative h-48 overflow-hidden">
              <img
                src={vehicle.images?.[0] || 'https://placehold.co/600x400/1F2937/9CA3AF?text=No+Image'}
                alt={vehicle.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              {/* Status badge with tooltip */}
              <div className="absolute top-3 left-3">
                <div className="relative group/tip">
                  <span className={`px-2 py-1 text-xs font-semibold rounded-full flex items-center gap-1 ${
                    vehicle.status === 'active' ? 'bg-green-500/80 text-white' : 'bg-red-500/80 text-white'
                  }`}>
                    {vehicle.status === 'active' ? 'Active' : 'Inactive'}
                    <FiInfo size={10} className="cursor-help" />
                  </span>
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-800 text-xs text-white rounded whitespace-nowrap opacity-0 group-hover/tip:opacity-100 transition pointer-events-none z-20">
                    {getVehicleStatusDescription(vehicle.status)}
                  </div>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="p-5">
              <h2 className="font-bold text-xl text-white line-clamp-1 group-hover:text-accent transition-colors">
                {vehicle.title}
              </h2>
              <div className="flex items-center gap-2 mt-1 text-sm text-gray-400">
                <FiMapPin className="text-accent" size={14} />
                <span>{vehicle.location}</span>
              </div>
              <div className="flex items-center gap-2 mt-2 text-accent font-bold">
                <FiDollarSign className="text-accent" />
                <span className="text-2xl font-black">{formatCurrency(vehicle.pricePerDay)}<span className="text-sm font-normal text-gray-400">/day</span></span>
              </div>            
              {/* Action buttons */}
              <div className="flex items-center justify-between mt-4 pt-3 border-t border-white/10">
                <Link
                  to={`/vehicles/${vehicle._id}`}
                  className="text-gray-300 hover:text-accent text-sm flex items-center gap-1 transition"
                >
                  <FiEye size={14} /> Preview
                </Link>
                <div className="flex gap-3">
                  <Link
                    to={`/dashboard/listings/${vehicle._id}/edit`}
                    className="text-accent hover:text-accent-hover transition flex items-center gap-1 text-sm"
                  >
                    <FiEdit size={14} /> Edit
                  </Link>
                  <button
                    onClick={() => handleDelete(vehicle._id)}
                    className="text-red-400 hover:text-red-500 transition flex items-center gap-1 text-sm"
                  >
                    <FiTrash2 size={14} /> Delete
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
export default OwnerListings;