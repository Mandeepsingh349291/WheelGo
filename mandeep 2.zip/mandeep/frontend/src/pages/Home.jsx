import { Link } from 'react-router-dom';
import { useEffect, useState, useRef } from 'react';
import { motion, useAnimation, useMotionValue, useTransform, AnimatePresence } from 'framer-motion';
import api from '../api';
import VehicleCard from '../components/VehicleCard';
import Spinner from '../components/ui/Spinner';
import { 
  AiFillStar, AiOutlineStar, AiOutlineSafety, AiOutlineGlobal, 
  AiOutlineCreditCard, AiOutlineCar, AiOutlineThunderbolt 
} from 'react-icons/ai';
import { FaUserFriends, FaShieldAlt, FaHeadset, FaQuoteLeft } from 'react-icons/fa';
import { BiMap, BiCalendarCheck } from 'react-icons/bi';
import { TbSpeedboat } from 'react-icons/tb';

/* ============================================
   Enhanced Particle Field (more dynamic)
============================================ */
const ParticleField = () => {
  const canvasRef = useRef(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let animationFrameId;
    let particles = [];
    let mouseX = 0, mouseY = 0;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);
    window.addEventListener('mousemove', (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    });

    class Particle {
      constructor() {
        this.reset();
      }
      reset() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.size = Math.random() * 2 + 0.5;
        this.speedX = (Math.random() - 0.5) * 0.4;
        this.speedY = (Math.random() - 0.5) * 0.4;
        this.opacity = Math.random() * 0.6 + 0.2;
      }
      update() {
        // Attract to mouse
        const dx = mouseX - this.x;
        const dy = mouseY - this.y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        if (dist < 150) {
          const angle = Math.atan2(dy, dx);
          const force = (150 - dist) / 150 * 0.5;
          this.x -= Math.cos(angle) * force;
          this.y -= Math.sin(angle) * force;
        }
        this.x += this.speedX;
        this.y += this.speedY;
        if (this.x < 0 || this.x > canvas.width || this.y < 0 || this.y > canvas.height) {
          this.reset();
        }
      }
      draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(245, 158, 11, ${this.opacity})`;
        ctx.fill();
      }
    }

    for (let i = 0; i < 180; i++) particles.push(new Particle());

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach(p => {
        p.update();
        p.draw();
      });
      animationFrameId = requestAnimationFrame(animate);
    };
    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', () => {});
    };
  }, []);

  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none" style={{ zIndex: 0 }} />;
};

/* ============================================
   Typing Effect (improved)
============================================ */
const TypingText = ({ words, className }) => {
  const [text, setText] = useState('');
  const [wordIndex, setWordIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const currentWord = words[wordIndex];
    const timeout = setTimeout(() => {
      if (!isDeleting && charIndex < currentWord.length) {
        setText(prev => prev + currentWord[charIndex]);
        setCharIndex(charIndex + 1);
      } else if (isDeleting && charIndex > 0) {
        setText(prev => prev.slice(0, -1));
        setCharIndex(charIndex - 1);
      } else if (!isDeleting && charIndex === currentWord.length) {
        setTimeout(() => setIsDeleting(true), 1500);
      } else if (isDeleting && charIndex === 0) {
        setIsDeleting(false);
        setWordIndex(prev => (prev + 1) % words.length);
      }
    }, isDeleting ? 50 : 100);
    return () => clearTimeout(timeout);
  }, [charIndex, isDeleting, wordIndex, words]);

  return (
    <span className={className}>
      {text}
      <motion.span
        animate={{ opacity: [0, 1] }}
        transition={{ duration: 0.5, repeat: Infinity, repeatType: 'reverse' }}
        className="ml-1 text-accent"
      >
        |
      </motion.span>
    </span>
  );
};

/* ============================================
   Animated Counter (smoother)
============================================ */
const AnimatedCounter = ({ value, suffix = '' }) => {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let start = 0;
    const duration = 1500;
    const increment = value / (duration / 16);
    const timer = setInterval(() => {
      start += increment;
      if (start >= value) {
        setCount(value);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);
    return () => clearInterval(timer);
  }, [value]);
  return <span>{count}{suffix}</span>;
};

/* ============================================
   Glowing CTA Button
============================================ */
const GlowButton = ({ children, to, variant = 'primary' }) => (
  <Link to={to} className="relative inline-block group">
    <div className="absolute -inset-0.5 bg-gradient-to-r from-accent to-primary-light rounded-full blur opacity-75 group-hover:opacity-100 transition duration-300 animate-pulse" />
    <span className="relative inline-block bg-accent hover:bg-accent-hover text-white font-bold px-10 py-4 rounded-full transition-all text-lg shadow-lg transform group-hover:scale-105">
      {children}
    </span>
  </Link>
);

/* ============================================
   Search Bar with animations & better UX
============================================ */
const SearchBar = () => {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [isFocused, setIsFocused] = useState(false);
  const timeoutRef = useRef(null);

  useEffect(() => {
    if (query.length < 2) {
      setSuggestions([]);
      return;
    }
    clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(async () => {
      try {
        const res = await api.get('/vehicles', { params: { query, limit: 4 } });
        setSuggestions(res?.data?.vehicles || []);
      } catch (e) {}
    }, 300);
    return () => clearTimeout(timeoutRef.current);
  }, [query]);

  return (
    <div className="w-full max-w-2xl mx-auto relative mt-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="flex items-center bg-white/5 backdrop-blur-md rounded-full border border-white/20 shadow-2xl"
      >
        <input
          type="text"
          placeholder="🔍 Search cars, bikes, locations..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setTimeout(() => setIsFocused(false), 200)}
          className="w-full py-5 px-8 bg-transparent rounded-l-full text-white placeholder-gray-300 focus:outline-none"
        />
        <Link
          to={`/search?query=${query}`}
          className="bg-accent hover:bg-accent-hover text-white font-semibold py-5 px-10 rounded-r-full transition-all duration-300"
        >
          Explore
        </Link>
      </motion.div>
      <AnimatePresence>
        {isFocused && suggestions.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-full mt-2 w-full bg-surface-light border border-surface-border rounded-2xl overflow-hidden shadow-2xl z-20"
          >
            {suggestions.map((v) => (
              <Link key={v._id} to={`/vehicles/${v._id}`} className="block px-6 py-4 hover:bg-surface-border transition-colors text-white">
                <div className="flex items-center gap-3">
                  <img src={v.images?.[0] || '/assets/placeholder.jpg'} alt="" className="w-10 h-10 rounded object-cover" />
                  <div>
                    <p className="font-semibold">{v.title}</p>
                    <p className="text-sm text-gray-400">{v.location}</p>
                  </div>
                </div>
              </Link>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

/* ============================================
   Scroll Reveal Wrapper (unchanged)
============================================ */
const ScrollReveal = ({ children, className, delay = 0 }) => {
  const controls = useAnimation();
  const ref = useRef(null);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) controls.start('visible');
      },
      { threshold: 0.1, rootMargin: '0px 0px -100px 0px' }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [controls]);
  return (
    <motion.div
      ref={ref}
      initial="hidden"
      animate={controls}
      variants={{
        hidden: { opacity: 0, y: 50 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.6, delay, ease: 'easeOut' } },
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

/* ============================================
   Tilt Card (enhanced)
============================================ */
const TiltCard = ({ children }) => {
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateX = useTransform(y, [-0.5, 0.5], [8, -8]);
  const rotateY = useTransform(x, [-0.5, 0.5], [-8, 8]);
  const handleMouseMove = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const width = rect.width, height = rect.height;
    const mouseX = e.clientX - rect.left, mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5, yPct = mouseY / height - 0.5;
    x.set(xPct); y.set(yPct);
  };
  const handleMouseLeave = () => { x.set(0); y.set(0); };
  return (
    <motion.div style={{ perspective: 1000 }} onMouseMove={handleMouseMove} onMouseLeave={handleMouseLeave} className="group">
      <motion.div style={{ rotateX, rotateY, transition: 'transform 0.1s' }} className="relative">
        {children}
      </motion.div>
    </motion.div>
  );
};

/* ============================================
   Main Home Component
============================================ */
const Home = () => {
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ users: 0, vehicles: 0, bookings: 0, cities: 0 });

  useEffect(() => {
    api.get('/vehicles?limit=6&sort=rating')
      .then(res => setVehicles(res?.data?.vehicles || []))
      .catch(err => console.error(err))
      .finally(() => setLoading(false));
    // Simulated stats (replace with real endpoint later)
    setStats({ users: 2847, vehicles: 523, bookings: 10234, cities: 28 });
  }, []);

  return (
    <div className="relative overflow-x-hidden bg-gradient-to-b from-primary-dark via-surface to-black">
      <ParticleField />

      {/* HERO SECTION - Modern Glassmorphism */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 pb-32">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-dark/70 via-surface/60 to-black/80 z-0" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 120 }}
              className="inline-block bg-accent/20 backdrop-blur-md rounded-full px-4 py-1 mb-6 text-accent text-sm font-semibold"
            >
              ✨ Germany's #1 Peer-to-Peer Rental
            </motion.div>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-extrabold text-white leading-tight">
              Rent the{' '}
              <TypingText 
                words={['perfect car', 'dream bike', 'ultimate ride', 'luxury SUV']} 
                className="text-accent bg-gradient-to-r from-accent to-yellow-300 bg-clip-text text-transparent" 
              />
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 mt-6 max-w-2xl mx-auto">
              Join a community of thousands. List your vehicle or rent one in seconds. <br />
              Secure, insured, and full of freedom.
            </p>
            <SearchBar />
          </motion.div>

          {/* Floating Elements */}
          <motion.div
            className="absolute left-5 top-1/3 hidden lg:block opacity-30"
            animate={{ y: [0, -20, 0], rotate: [0, 5, -5, 0] }}
            transition={{ duration: 8, repeat: Infinity }}
          >
            <AiOutlineCar className="text-7xl text-accent" />
          </motion.div>
          <motion.div
            className="absolute right-10 bottom-20 hidden lg:block opacity-30"
            animate={{ y: [0, 20, 0], rotate: [0, -10, 10, 0] }}
            transition={{ duration: 7, repeat: Infinity }}
          >
            <TbSpeedboat className="text-6xl text-accent" />
          </motion.div>

          {/* Scroll Down Indicator */}
          <motion.div
            className="absolute -bottom-32 left-1/2 -translate-x-1/2"
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <div className="w-6 h-10 border-2 border-accent rounded-full flex justify-center">
              <div className="w-1 h-2 bg-accent rounded-full mt-2 animate-pulse" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* STATS SECTION - Enhanced with icons */}
      <section className="relative py-16 bg-black/30 backdrop-blur-sm border-y border-white/10">
        <div className="max-w-7xl mx-auto px-4">
          <ScrollReveal className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="flex flex-col items-center">
              <div className="text-4xl text-accent mb-2"><FaUserFriends /></div>
              <div className="text-3xl md:text-4xl font-bold text-white"><AnimatedCounter value={stats.users} />+</div>
              <p className="text-gray-300 mt-1">Active Users</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-4xl text-accent mb-2"><AiOutlineCar /></div>
              <div className="text-3xl md:text-4xl font-bold text-white"><AnimatedCounter value={stats.vehicles} />+</div>
              <p className="text-gray-300 mt-1">Vehicles Listed</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-4xl text-accent mb-2"><BiCalendarCheck /></div>
              <div className="text-3xl md:text-4xl font-bold text-white"><AnimatedCounter value={stats.bookings} />K+</div>
              <p className="text-gray-300 mt-1">Successful Bookings</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="text-4xl text-accent mb-2"><AiOutlineGlobal /></div>
              <div className="text-3xl md:text-4xl font-bold text-white"><AnimatedCounter value={stats.cities} /></div>
              <p className="text-gray-300 mt-1">Cities Covered</p>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* CATEGORIES SECTION - New */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <ScrollReveal className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Browse by Category</h2>
            <p className="text-gray-300 text-lg">Find exactly what you're looking for</p>
          </ScrollReveal>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { name: 'Luxury Cars', icon: <AiOutlineCar className="text-4xl" />, color: 'from-red-500 to-pink-500', link: '/search?type=car&minPrice=150' },
              { name: 'Economy', icon: <AiOutlineThunderbolt className="text-4xl" />, color: 'from-green-500 to-teal-500', link: '/search?type=car&maxPrice=50' },
              { name: 'Motorcycles', icon: <TbSpeedboat className="text-4xl" />, color: 'from-blue-500 to-cyan-500', link: '/search?type=bike' },
              { name: 'SUVs & Vans', icon: <AiOutlineSafety className="text-4xl" />, color: 'from-orange-500 to-yellow-500', link: '/search?type=car&seats=5' },
            ].map((cat) => (
              <Link to={cat.link} key={cat.name}>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className={`bg-gradient-to-br ${cat.color} p-6 rounded-2xl shadow-xl text-white text-center transition-all hover:shadow-2xl cursor-pointer`}
                >
                  <div className="flex justify-center mb-3">{cat.icon}</div>
                  <h3 className="text-xl font-bold">{cat.name}</h3>
                </motion.div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED VEHICLES - larger grid */}
      <section className="py-20 bg-black/20">
        <div className="max-w-7xl mx-auto px-4">
          <ScrollReveal className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">🔥 Featured Rides</h2>
            <p className="text-gray-300 text-lg">Top-rated vehicles by our community</p>
          </ScrollReveal>
          {loading ? (
            <Spinner />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {vehicles.map(v => (
                <TiltCard key={v._id}>
                  <VehicleCard vehicle={v} />
                </TiltCard>
              ))}
            </div>
          )}
          <div className="text-center mt-12">
            <Link to="/search" className="inline-flex items-center gap-2 text-accent hover:text-accent-hover font-semibold text-lg transition-all">
              View all vehicles <span className="text-xl">→</span>
            </Link>
          </div>
        </div>
      </section>

      {/* HOW IT WORKS - with better icons and animations */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <ScrollReveal className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Simple 3‑Step Process</h2>
            <p className="text-gray-300 text-lg">Get on the road in minutes</p>
          </ScrollReveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { step: '01', title: 'Search & Select', desc: 'Browse thousands of vehicles, filter by date, price, and location.', icon: <BiMap className="text-5xl" /> },
              { step: '02', title: 'Book & Pay', desc: 'Request a booking, get instant approval, and pay securely via PayPal.', icon: <AiOutlineCreditCard className="text-5xl" /> },
              { step: '03', title: 'Enjoy the Ride', desc: 'Pick up the keys, drive, and return. Insurance included.', icon: <AiOutlineCar className="text-5xl" /> },
            ].map((item, idx) => (
              <ScrollReveal key={idx} delay={idx * 0.1}>
                <div className="relative bg-surface-light/40 backdrop-blur-md p-8 rounded-2xl border border-white/10 text-center hover:border-accent/50 transition-all group">
                  <div className="absolute -top-5 left-1/2 -translate-x-1/2 bg-accent text-white w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg shadow-lg">
                    {idx + 1}
                  </div>
                  <div className="text-accent mb-4 group-hover:scale-110 transition-transform duration-300">{item.icon}</div>
                  <h3 className="text-2xl font-bold text-white mb-2">{item.title}</h3>
                  <p className="text-gray-300">{item.desc}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS SECTION - New */}
      <section className="py-20 bg-gradient-to-r from-primary-dark/50 to-surface/50">
        <div className="max-w-7xl mx-auto px-4">
          <ScrollReveal className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">❤️ Loved by thousands</h2>
            <p className="text-gray-300 text-lg">What our community says</p>
          </ScrollReveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { name: 'Anna M.', role: 'Renter', text: 'The easiest rental experience ever! Found a perfect car in minutes and the owner was super helpful.', rating: 5 },
              { name: 'Felix K.', role: 'Owner', text: 'Listed my bike and earned over 1000€ in two months. The platform handles everything securely.', rating: 5 },
              { name: 'Laura S.', role: 'Renter', text: 'Great selection, fair prices, and the insurance gave me peace of mind. Will use again!', rating: 5 },
            ].map((t, i) => (
              <motion.div key={i} whileHover={{ y: -5 }} className="bg-surface-light p-6 rounded-2xl border border-white/10">
                <FaQuoteLeft className="text-accent/40 text-3xl mb-3" />
                <p className="text-gray-200 mb-4">"{t.text}"</p>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-white">{t.name}</p>
                    <p className="text-sm text-gray-400">{t.role}</p>
                  </div>
                  <div className="flex text-accent">
                    {[...Array(t.rating)].map((_, i) => <AiFillStar key={i} />)}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US - Features Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4">
          <ScrollReveal className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Why choose WheelGo?</h2>
            <p className="text-gray-300 text-lg">The smarter way to rent</p>
          </ScrollReveal>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: <FaShieldAlt />, title: 'Full Insurance', desc: 'Every rental includes liability and damage coverage.' },
              { icon: <AiOutlineCreditCard />, title: 'Secure Payments', desc: 'PayPal integration – your money is safe.' },
              { icon: <FaHeadset />, title: '24/7 Support', desc: 'Our team is always ready to help.' },
              { icon: <AiOutlineGlobal />, title: 'Local & Global', desc: 'Rent from owners in your city or anywhere.' },
            ].map((feat, idx) => (
              <ScrollReveal key={idx} delay={idx * 0.05}>
                <div className="text-center p-6 rounded-xl bg-white/5 backdrop-blur-sm border border-white/10 hover:border-accent/40 transition-all">
                  <div className="text-accent text-4xl mb-3 flex justify-center">{feat.icon}</div>
                  <h3 className="text-xl font-bold text-white mb-2">{feat.title}</h3>
                  <p className="text-gray-300 text-sm">{feat.desc}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>
      {/* DOWNLOAD APP / NEWSLETTER SECTION */}
      <section className="py-20 bg-black/40">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <ScrollReveal>
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">Start your journey today</h2>
            <p className="text-gray-300 text-lg mb-8">Join the fastest-growing rental community in Germany.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <GlowButton to="/register">Create free account</GlowButton>
              <Link to="/search" className="inline-block bg-white/10 backdrop-blur-md border border-white/20 text-white font-semibold py-4 px-8 rounded-full hover:bg-white/20 transition-all">
                Browse vehicles →
              </Link>
            </div>
          </ScrollReveal>
        </div>
      </section>
    </div>
  );
};
export default Home;