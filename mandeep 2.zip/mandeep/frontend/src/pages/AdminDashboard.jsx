import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FiUsers, FiGrid, FiBookOpen, FiSearch, FiX, FiUserX, 
  FiTrash2, FiCalendar, FiMapPin, FiDollarSign, FiUser
} from 'react-icons/fi';
import api from '../api';
import Button from '../components/ui/Button';
import Spinner from '../components/ui/Spinner';
import Badge from '../components/ui/Badge';
import { formatDate, formatCurrency } from '../utils/helpers';
import toast from 'react-hot-toast';

const AdminDashboard = () => {
  const [tab, setTab] = useState('users');
  const [users, setUsers] = useState([]);
  const [listings, setListings] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Safe data fetching with proper response handling
  const fetchUsers = async () => {
  setLoading(true);
  try {
    const res = await api.get('/admin/users');
    setUsers(res?.data?.users || []);
  } catch (err) {
    toast.error(err.message || 'Failed to fetch users');
    setUsers([]);
  } finally {
    setLoading(false);
  }
};

const fetchListings = async () => {
  setLoading(true);
  try {
    const res = await api.get('/admin/vehicles');
    setListings(res?.data?.vehicles || []);
  } catch (err) {
    toast.error(err.message || 'Failed to fetch listings');
    setListings([]);
  } finally {
    setLoading(false);
  }
};

const fetchBookings = async () => {
  setLoading(true);
  try {
    const res = await api.get('/admin/bookings');
    setBookings(res?.data?.bookings || []);
  } catch (err) {
    toast.error(err.message || 'Failed to fetch bookings');
    setBookings([]);
  } finally {
    setLoading(false);
  }
};

  useEffect(() => {
    if (tab === 'users') fetchUsers();
    else if (tab === 'listings') fetchListings();
    else fetchBookings();
  }, [tab]);

  const handleDeactivateUser = async (id) => {
    if (!window.confirm('Deactivate this user? They will no longer be able to log in.')) return;
    try {
      await api.patch(`/admin/users/${id}/status`, { isActive: false });
      toast.success('User deactivated');
      fetchUsers();
    } catch (err) { 
      toast.error(err.message); 
    }
  };

  const handleDeleteListing = async (id) => {
    if (!window.confirm('Delete this listing? This action cannot be undone.')) return;
    try {
      await api.delete(`/vehicles/${id}`);
      toast.success('Listing deleted');
      fetchListings();
    } catch (err) { 
      toast.error(err.message); 
    }
  };

  const handleCancelBooking = async (id) => {
  if (!window.confirm('Cancel this booking?')) return;
  try {
    await api.patch(`/bookings/${id}/cancel`);
    toast.success('Booking cancelled');
    fetchBookings();
  } catch (err) {
    toast.error(err.message);
  }
};

const handleUpdatePaymentStatus = async (id, paymentStatus) => {
  try {
    await api.patch(`/admin/bookings/${id}/payment-status`, { paymentStatus });
    toast.success('Payment status updated');
    fetchBookings();
  } catch (err) {
    toast.error(err.message);
  }
};

  // Safe filtering
  const filteredUsers = users.filter(u => 
    u?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u?.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const filteredListings = listings.filter(l => 
    l?.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    l?.ownerId?.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const filteredBookings = bookings.filter(b => 
    b?.vehicleId?.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b?.renterId?.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const tabs = [
    { id: 'users', label: 'Users', icon: FiUsers, count: users.length },
    { id: 'listings', label: 'Listings', icon: FiGrid, count: listings.length },
    { id: 'bookings', label: 'Bookings', icon: FiBookOpen, count: bookings.length },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl md:text-4xl font-bold text-white">Admin Dashboard</h1>
        <p className="text-gray-400 mt-1">Manage users, vehicles, and bookings</p>
      </div>
      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-white/10 pb-2">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-medium transition-all duration-200 ${
              tab === t.id
                ? 'bg-accent text-white shadow-lg shadow-accent/20'
                : 'text-gray-400 hover:text-white hover:bg-white/10'
            }`}
          >
            <t.icon size={18} />
            {t.label}
            <span className={`text-xs px-2 py-0.5 rounded-full ${
              tab === t.id ? 'bg-white/20 text-white' : 'bg-white/10 text-gray-300'
            }`}>
              {t.count}
            </span>
          </button>
        ))}
      </div>
      {/* Search */}
      <div className="relative">
        <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          placeholder={`Search ${tab}...`}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-11 pr-10 text-white placeholder-gray-400 focus:outline-none focus:border-accent transition"
        />
        {searchTerm && (
          <button
            onClick={() => setSearchTerm('')}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
          >
            <FiX size={18} />
          </button>
        )}
      </div>
      {/* Content */}
      {loading ? (
        <div className="flex justify-center py-20">
          <Spinner size={60} color="#F59E0B" />
        </div>
      ) : (
        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {tab === 'users' && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredUsers.map((user) => (
                  <div key={user._id} className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-5 hover:border-accent/30 transition-all">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <img
                          src={user.avatarUrl || `https://ui-avatars.com/api/?background=F59E0B&color=fff&name=${encodeURIComponent(user.name || 'User')}`}
                          alt={user.name}
                          className="w-12 h-12 rounded-full object-cover border-2 border-accent/50"
                        />
                        <div>
                          <h3 className="font-semibold text-white">{user.name || 'Unknown'}</h3>
                          <p className="text-xs text-gray-400">{user.email || 'No email'}</p>
                        </div>
                      </div>
                      <Badge status={user.role || 'renter'} />
                    </div>
                    <div className="mt-3 flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded-full text-xs ${user.isActive ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                          {user.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                      <button
                        onClick={() => handleDeactivateUser(user._id)}
                        className="text-red-400 hover:text-red-300 text-sm flex items-center gap-1"
                      >
                        <FiUserX size={14} /> Deactivate
                      </button>
                    </div>
                  </div>
                ))}
                {filteredUsers.length === 0 && (
                  <div className="col-span-full text-center py-10 text-gray-400">No users found</div>
                )}
              </div>
            )}
            {tab === 'listings' && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredListings.map((listing) => (
                  <div key={listing._id} className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 overflow-hidden hover:border-accent/30 transition-all">
                    <img
                      src={listing.images?.[0] || 'https://placehold.co/600x400/1F2937/9CA3AF?text=No+Image'}
                      alt={listing.title || 'Vehicle'}
                      className="w-full h-40 object-cover"
                    />
                    <div className="p-4">
                      <div className="flex justify-between items-start">
                        <h3 className="font-bold text-white line-clamp-1">{listing.title || 'Untitled'}</h3>
                        <Badge status={listing.status || 'inactive'} />
                      </div>
                      <p className="text-sm text-gray-400 mt-1 flex items-center gap-1">
                        <FiUser size={12} /> {listing.ownerId?.name || 'Unknown owner'}
                      </p>
                      <div className="flex items-center gap-2 mt-2 text-accent font-bold">
                        <FiDollarSign />
                        <span>{formatCurrency(listing.pricePerDay || 0)}<span className="text-xs text-gray-400">/day</span></span>
                      </div>
                      <div className="flex justify-between items-center mt-3 pt-2 border-t border-white/10">
                        <span className="text-xs text-gray-400 flex items-center gap-1"><FiMapPin /> {listing.location || 'No location'}</span>
                        <button
                          onClick={() => handleDeleteListing(listing._id)}
                          className="text-red-400 hover:text-red-300 text-sm flex items-center gap-1"
                        >
                          <FiTrash2 size={14} /> Delete
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
                {filteredListings.length === 0 && (
                  <div className="col-span-full text-center py-10 text-gray-400">No listings found</div>
                )}
              </div>
            )}
            {tab === 'bookings' && (
  <div className="space-y-3">
    {filteredBookings.map((booking) => (
      <div key={booking._id} className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-4 hover:border-accent/30 transition-all">
        <div className="flex flex-wrap justify-between items-start gap-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-semibold text-white">{booking.vehicleId?.title || 'Vehicle'}</h3>
              <Badge status={booking.status || 'pending'} />
              <Badge status={booking.paymentStatus || 'pending'} />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1 mt-2 text-sm text-gray-300">
              <span className="flex items-center gap-1"><FiUser /> Renter: {booking.renterId?.name || 'N/A'}</span>
              <span className="flex items-center gap-1"><FiCalendar /> {formatDate(booking.startDate)} – {formatDate(booking.endDate)}</span>
              <span className="flex items-center gap-1"><FiDollarSign /> Total: {formatCurrency(booking.totalPrice || 0)}</span>
              <span className="flex items-center gap-1"><FiMapPin /> {booking.vehicleId?.location || 'N/A'}</span>
            </div>
            {/* Payment status updater */}
            <div className="flex items-center gap-3 mt-3 pt-3 border-t border-white/10">
              <span className="text-xs text-gray-400">Update payment status:</span>
              <select
                value={booking.paymentStatus || 'pending'}
                onChange={(e) => handleUpdatePaymentStatus(booking._id, e.target.value)}
                className="bg-gray-800 border border-white/20 text-white text-xs rounded-lg px-2 py-1 focus:outline-none focus:border-accent"
              >
                <option value="pending">Pending</option>
                <option value="paid">Paid</option>
                <option value="refunded">Refunded</option>
                <option value="failed">Failed</option>
              </select>
            </div>
          </div>
          <button
            onClick={() => handleCancelBooking(booking._id)}
            className="text-red-400 hover:text-red-300 text-sm flex items-center gap-1 self-start"
          >
            <FiX size={14} /> Cancel
          </button>
        </div>
      </div>
    ))}
    {filteredBookings.length === 0 && (
      <div className="text-center py-10 text-gray-400">No bookings found</div>
    )}
  </div>
)}
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  );
};
export default AdminDashboard;