import { Link } from 'react-router-dom';

const NotFound = () => (
  <div className="text-center py-20">
    <h1 className="text-6xl font-bold text-accent">404</h1>
    <p className="text-xl mt-4 mb-8 text-gray-300">Page not found</p>
    <Link to="/" className="btn-primary">Go Home</Link>
  </div>
);
export default NotFound;