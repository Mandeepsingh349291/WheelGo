const User = require('../models/User');
const { successResponse } = require('../utils/response');
const { comparePassword } = require('../utils/hash');

const getProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id).select('-passwordHash');
    successResponse(res, user);
  } catch (err) {
    next(err);
  }
};

const updateProfile = async (req, res, next) => {
  try {
    const { name, phone } = req.body;
    const update = {};
    if (name) update.name = name;
    if (phone !== undefined) update.phone = phone;
    const user = await User.findByIdAndUpdate(req.user.id, update, { new: true }).select('-passwordHash');
    successResponse(res, user, 'Profile updated');
  } catch (err) {
    next(err);
  }
};

const changePassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = await User.findById(req.user.id);
    if (!(await user.comparePassword(currentPassword))) {
      return res.status(400).json({ success: false, message: 'Current password is incorrect' });
    }
    user.passwordHash = newPassword; // will be hashed by pre-save hook
    await user.save();
    successResponse(res, null, 'Password updated');
  } catch (err) {
    next(err);
  }
};

const uploadAvatar = async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });
    const avatarUrl = req.file.path;
    const user = await User.findByIdAndUpdate(req.user.id, { avatarUrl }, { new: true }).select('-passwordHash');
    successResponse(res, user, 'Avatar uploaded');
  } catch (err) {
    next(err);
  }
};

module.exports = { getProfile, updateProfile, changePassword, uploadAvatar };


