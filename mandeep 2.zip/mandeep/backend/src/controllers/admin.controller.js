const User = require('../models/User');
const Vehicle = require('../models/Vehicle');
const Booking = require('../models/Booking');
const Review = require('../models/Review');
const Report = require('../models/Report');
const { successResponse } = require('../utils/response');
const notificationService = require('../services/notification.service');

// Platform overview dashboard
const getDashboard = async (req, res, next) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalVehicles = await Vehicle.countDocuments();
    const totalBookings = await Booking.countDocuments();
    const pendingBookings = await Booking.countDocuments({ status: 'pending' });
    const completedBookings = await Booking.countDocuments({ status: 'completed' });

    // Aggregate revenue from payments (simplified)
    const Payment = require('../models/Payment');
    const revenue = await Payment.aggregate([
      { $match: { status: 'captured' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);
    const totalRevenue = revenue.length > 0 ? revenue[0].total : 0;

    successResponse(res, {
      totalUsers,
      totalVehicles,
      totalBookings,
      pendingBookings,
      completedBookings,
      totalRevenue,
    });
  } catch (err) {
    next(err);
  }
};

// Get all users with optional role filter
const getUsers = async (req, res, next) => {
  try {
    const { role, page = 1, limit = 20 } = req.query;
    const query = {};
    if (role) query.role = role;
    const total = await User.countDocuments(query);
    const users = await User.find(query)
      .select('-passwordHash')
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .sort('-createdAt');
    successResponse(res, { users, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    next(err);
  }
};

// Get all vehicles with filters and moderation flags
const getVehicles = async (req, res, next) => {
  try {
    const { status, isApproved, page = 1, limit = 20 } = req.query;
    const query = {};
    if (status) query.status = status;
    if (isApproved !== undefined) query.isApproved = isApproved === 'true';
    const total = await Vehicle.countDocuments(query);
    const vehicles = await Vehicle.find(query)
      .populate('ownerId', 'name email')
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .sort('-createdAt');
    successResponse(res, { vehicles, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    next(err);
  }
};

// Approve or flag a vehicle
const moderateVehicle = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { isApproved, status } = req.body;
    const update = {};
    if (typeof isApproved === 'boolean') update.isApproved = isApproved;
    if (status) update.status = status;
    const vehicle = await Vehicle.findByIdAndUpdate(id, update, { new: true });
    if (!vehicle) return res.status(404).json({ success: false, message: 'Vehicle not found' });
    successResponse(res, vehicle, 'Vehicle moderation updated');
  } catch (err) {
    next(err);
  }
};

// Get all bookings
const getBookings = async (req, res, next) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const query = {};
    if (status) query.status = status;
    const total = await Booking.countDocuments(query);
    const bookings = await Booking.find(query)
      .populate('renterId', 'name email')
      .populate('ownerId', 'name email')
      .populate('vehicleId', 'title')
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .sort('-createdAt');
    successResponse(res, { bookings, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    next(err);
  }
};

// Get and resolve reports
const getReports = async (req, res, next) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const query = {};
    if (status) query.status = status;
    const total = await Report.countDocuments(query);
    const reports = await Report.find(query)
      .populate('reporterId', 'name email')
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .sort('-createdAt');
    successResponse(res, { reports, total, page: Number(page), pages: Math.ceil(total / limit) });
  } catch (err) {
    next(err);
  }
};

const resolveReport = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, adminNote } = req.body;
    const report = await Report.findByIdAndUpdate(id, { status, adminNote }, { new: true });
    if (!report) return res.status(404).json({ success: false, message: 'Report not found' });
    successResponse(res, report, 'Report updated');
  } catch (err) {
    next(err);
  }
};

// Suspend or activate a user
const updateUserStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { isActive } = req.body;
    const user = await User.findByIdAndUpdate(id, { isActive }, { new: true }).select('-passwordHash');
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    successResponse(res, user, 'User status updated');
  } catch (err) {
    next(err);
  }
};

const updateBookingPaymentStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { paymentStatus } = req.body;

    const validStatuses = ['pending', 'paid', 'refunded', 'failed'];
    // if (!validStatuses.includes(paymentStatus)) {
    //   return res.status(400).json({ success: false, message: 'Invalid payment status' });
    // }

    const booking = await Booking.findByIdAndUpdate(
      id,
      { paymentStatus },
      { new: true }
    )
      .populate('renterId', 'name email')
      .populate('ownerId', 'name email')
      .populate('vehicleId', 'title');

    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found' });

    // Notify renter about payment status change
    const statusMessages = {
      paid: 'Your payment has been confirmed by admin.',
      refunded: 'Your payment has been refunded by admin.',
      failed: 'Your payment has been marked as failed by admin.',
      pending: 'Your payment status has been reset to pending by admin.',
    };

    await notificationService.createNotification(
      booking.renterId._id,
      'payment',
      'Payment Status Updated',
      `Booking for "${booking.vehicleId?.title}": ${statusMessages[paymentStatus]}`,
      { bookingId: booking._id }
    );

    // Also notify owner
    await notificationService.createNotification(
      booking.ownerId._id,
      'payment',
      'Payment Status Updated',
      `Payment for booking "${booking.vehicleId?.title}" has been marked as ${paymentStatus} by admin.`,
      { bookingId: booking._id }
    );

    successResponse(res, booking, 'Payment status updated');
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getDashboard,
  getUsers,
  getVehicles,
  moderateVehicle,
  getBookings,
  getReports,
  resolveReport,
  updateUserStatus,
  updateBookingPaymentStatus,
};
