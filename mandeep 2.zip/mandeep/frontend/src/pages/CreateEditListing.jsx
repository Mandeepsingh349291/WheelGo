import { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../api';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import toast from 'react-hot-toast';

const defaultForm = {
  title: '',
  description: '',
  vehicleType: 'car',
  pricePerDay: '',
  location: '',
  seats: 4,
  transmission: 'manual',
  fuelType: 'petrol',
};

const CreateEditListing = () => {
  const { id } = useParams();
  const isEdit = !!id;
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  
  const [form, setForm] = useState(defaultForm);
  const [loading, setLoading] = useState(false);
  const [fetchLoading, setFetchLoading] = useState(isEdit);
  
  // Separate state for existing image URLs (from backend) and new image files
  const [existingImages, setExistingImages] = useState([]);
  const [newImageFiles, setNewImageFiles] = useState([]);
  const [newImagePreviews, setNewImagePreviews] = useState([]);

  useEffect(() => {
    if (isEdit) {
      api.get(`/vehicles/${id}`)
        .then(res => {
          const v = res;
          setForm({
            title: v.title,
            description: v.description,
            vehicleType: v.vehicleType,
            pricePerDay: v.pricePerDay,
            location: v.location,
            seats: v.seats,
            transmission: v.transmission,
            fuelType: v.fuelType,
          });
          setExistingImages(v.images || []);
        })
        .catch(err => toast.error('Failed to load vehicle'))
        .finally(() => setFetchLoading(false));
    }
  }, [id, isEdit]);

  // Cleanup object URLs when component unmounts or new files are added
  useEffect(() => {
    return () => {
      newImagePreviews.forEach(url => URL.revokeObjectURL(url));
    };
  }, [newImagePreviews]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleImageChange = (e) => {
    const files = Array.from(e.target.files);
    setNewImageFiles(files);
    
    // Generate previews and revoke old ones
    newImagePreviews.forEach(url => URL.revokeObjectURL(url));
    const previews = files.map(file => URL.createObjectURL(file));
    setNewImagePreviews(previews);
  };

  const removeExistingImage = (indexToRemove) => {
    setExistingImages(prev => prev.filter((_, idx) => idx !== indexToRemove));
  };

  const removeNewImage = (indexToRemove) => {
    // Revoke the object URL to avoid memory leak
    URL.revokeObjectURL(newImagePreviews[indexToRemove]);
    setNewImagePreviews(prev => prev.filter((_, idx) => idx !== indexToRemove));
    setNewImageFiles(prev => prev.filter((_, idx) => idx !== indexToRemove));
    // Reset file input value
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();

    // Append text fields
    Object.entries(form).forEach(([key, value]) => {
      formData.append(key, value);
    });

    // Append existing image URLs (as JSON string) – backend will know to keep them
    if (existingImages.length > 0) {
      formData.append('existingImages', JSON.stringify(existingImages));
    }

    // Append new image files
    for (let i = 0; i < newImageFiles.length; i++) {
      formData.append('images', newImageFiles[i]);
    }

    setLoading(true);
    try {
      if (isEdit) {
        await api.put(`/vehicles/${id}`, formData);
        toast.success('Vehicle updated');
      } else {
        await api.post('/vehicles', formData);
        toast.success('Vehicle created');
      }
      navigate('/dashboard/listings');
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (fetchLoading) {
    return <div className="text-center py-10 text-gray-400">Loading vehicle data...</div>;
  }

  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 text-white">
        {isEdit ? 'Edit' : 'Create'} Vehicle
      </h1>
      <form onSubmit={handleSubmit} className="bg-surface-light p-6 rounded-xl space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input label="Title" name="title" value={form.title} onChange={handleChange} required />
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-300">Vehicle Type</label>
            <select name="vehicleType" value={form.vehicleType} onChange={handleChange} className="input-dark w-full">
              <option value="car">Car</option>
              <option value="bike">Bike</option>
            </select>
          </div>
          <Input label="Price per Day (£)" type="number" name="pricePerDay" value={form.pricePerDay} onChange={handleChange} required min="0" />
          <Input label="Location" name="location" value={form.location} onChange={handleChange} required />
          <Input label="Seats" type="number" name="seats" value={form.seats} onChange={handleChange} />
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-300">Transmission</label>
            <select name="transmission" value={form.transmission} onChange={handleChange} className="input-dark w-full">
              <option value="automatic">Automatic</option>
              <option value="manual">Manual</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1 text-gray-300">Fuel Type</label>
            <select name="fuelType" value={form.fuelType} onChange={handleChange} className="input-dark w-full">
              <option value="petrol">Petrol</option>
              <option value="diesel">Diesel</option>
              <option value="electric">Electric</option>
              <option value="hybrid">Hybrid</option>
            </select>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1 text-gray-300">Description</label>
          <textarea name="description" rows={3} className="input-dark w-full" value={form.description} onChange={handleChange} />
        </div>

        {/* IMAGE UPLOAD SECTION */}
        <div>
          <label className="block text-sm font-medium mb-1 text-gray-300">Images</label>
          
          {/* Existing images (only in edit mode) */}
          {existingImages.length > 0 && (
            <div className="mb-3">
              <label className="block text-sm font-medium mb-2 text-gray-300">Current Images:</label>
              <div className="flex flex-wrap gap-3">
                {existingImages.map((url, idx) => (
                  <div key={idx} className="relative w-24 h-24 rounded-lg overflow-hidden border border-surface-border">
                    <img src={url} alt={`Existing ${idx + 1}`} className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => removeExistingImage(idx)}
                      className="absolute top-1 right-1 bg-red-600 rounded-full p-1 text-white text-xs hover:bg-red-700"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* New images preview */}
          {newImagePreviews.length > 0 && (
            <div className="mt-3">
              <label className="block text-sm font-medium mb-2 text-gray-300">New Images:</label>
              <div className="flex flex-wrap gap-3">
                {newImagePreviews.map((src, idx) => (
                  <div key={idx} className="relative w-24 h-24 rounded-lg overflow-hidden border border-surface-border">
                    <img src={src} alt={`Preview ${idx + 1}`} className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => removeNewImage(idx)}
                      className="absolute top-1 right-1 bg-red-600 rounded-full p-1 text-white text-xs hover:bg-red-700"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleImageChange}
            className="text-gray-300 mt-2"
            accept="image/*"
          />
          <p className="text-xs text-gray-500 mt-1">You can select multiple images. Existing images will be kept unless removed.</p>
        </div>

        <Button type="submit" disabled={loading} className="w-full">
          {loading ? 'Saving...' : isEdit ? 'Update Vehicle' : 'Create Vehicle'}
        </Button>
      </form>
    </div>
  );
};

export default CreateEditListing;