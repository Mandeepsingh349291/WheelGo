describe('Rating Aggregation Logic', () => {

  const calculateAverage = (ratings) => {
    if (ratings.length === 0) return 0;
    return ratings.reduce((sum, r) => sum + r, 0) / ratings.length;
  };

  test('UT-10: calculates correct average for multiple ratings', () => {
    const avg = calculateAverage([5, 4, 3, 5, 4]);
    expect(avg).toBe(4.2);
  });

  test('UT-11: returns 0 for empty ratings array', () => {
    const avg = calculateAverage([]);
    expect(avg).toBe(0);
  });

  test('UT-12: handles single rating correctly', () => {
    const avg = calculateAverage([5]);
    expect(avg).toBe(5);
  });
});